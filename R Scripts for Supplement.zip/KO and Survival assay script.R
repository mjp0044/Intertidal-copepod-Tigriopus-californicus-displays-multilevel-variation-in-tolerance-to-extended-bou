#KO and Survival Assay Script 
#Matthew Powers 
#powerm3@oregonstate.edu
#Combines analysis of KO assay data and generates figures
#Last edited 06-29-23

#load required packages
library(ggpubr) #Also loads basic ggplot2
library(cowplot) #Pretty ggplots!
library(reshape2) #Data wrangling
library(dplyr) #Data wrangling
library(tidyverse) #Data wrangling
library(stringr) #data wrangling for splitting column characters
library(MetBrewer) #Pretty colors!
library(runner) #Do functions on sliding windows of data
library(scales) #Pretty colors!
library(palettetown) #Pretty ggplots!
library(grid) #for adding tables to plots and making multiple panels
library(gridExtra) #for adding tables to plots and making multiple panels
library(glue) #Stick stuff in other stuff! Like pasting text in data frames and plot elements
library(patchwork) #stitching graphs together
library(ggiraph) #Connected interactive graphs
library(MESS) #data wrangling and modeling
library(stats) #data wrangling and modeling
library(lme4) #data wrangling and modeling
library(lmerTest) #Get null hypothesis test from lme4 lmer models
library(emmeans) #data wrangling and modeling
library(MuMIn) #For getting R squared values from mixed models
library(pscl) #For zero inflated poisson model


#Set theme globally
theme_set(theme_cowplot())

#Read in data 
  datum.KO = read.csv(file="KO.data.csv", header = TRUE)
  datum.surv = read.csv(file="Plate survival.csv", header = TRUE)

#Remove data points with less than 10 copepods
  datum.KO <- subset(datum.KO, Total.copepods == 10)
  datum.surv <- subset(datum.surv, Total.copepods == 10)

  
###Prep and summarize KO data
  
    #Relabel sex factor 
      datum.KO %>% 
      mutate(Sex = fct_recode(Sex, "Female" = "F",
                              "Male" = "M")) -> datum.KO
    
    #Combine sex and population factors for plotting or stats groupings 
      datum.KO$Pop.sex = paste(datum.KO$Sex, datum.KO$Pop)
    
      #Create lengthwise data frame for time series data
      ###Melt KO data frame to organize LOE data by group ID
          datum.KO2 = melt(datum.KO[,c(3, 8, 9, 10, 11, 12, 13, 14, 15, 28)], id=c("Replicate.ID", "Time.minutes", "Group")) #counts
          ##OR
          #datum2 = melt(datum[,c(3, 8, 20, 21, 22, 23, 24, 25, 26)], id=c("Replicate.ID", "Time.minutes")) #Proportion
          
          datum.KO2[c('Pop.sex', 'replicate')] <- str_split_fixed(datum.KO2$Replicate.ID, '[.]', 2)
          
        
          #Relabel time factor (choose 1 of 2 below)
          
          #for proportions
          # datum2 %>% 
          #   mutate(variable = fct_recode(variable, "0" = "Hour0.prop",
          #                           "1" = "Hour1.prop",
          #                           "2" = "Hour2.prop",
          #                           "3" = "Hour3.prop",
          #                           "4" = "Hour4.prop",
          #                           "5" = "Hour5.prop",
          #                           "6" = "Hour6.prop")) -> datum
          #OR for counts
          datum.KO2 %>% 
            mutate(variable = fct_recode(variable, "0" = "X0hr",
                                         "1" = "X1hr",
                                         "2" = "X2hr",
                                         "3" = "X3hr",
                                         "4" = "X4hr",
                                         "5" = "X5hr",
                                         "6" = "X6hr")) -> datum.KO2
    
          
          
          #Relabel group factor
          datum.KO2 %>% 
                mutate(Pop.sex = fct_recode(Pop.sex, "Female BOB" = "FBOB", 
                                          "Female BR" = "FBR", 
                                          "Female SD" = "FSD", 
                                          "Female SH" = "FSH", 
                                          "Male BOB" = "MBOB", 
                                          "Male BR" = "MBR", 
                                          "Male SD" = "MSD", 
                                          "Male SH" = "MSH")) -> datum.KO2
          
            #Make new columns with sex and pop split
          datum.KO2[c('Sex', 'Pop')] <- str_split_fixed(datum.KO2$Pop.sex, ' ', 2)
          
          datum.KO2$Sex = as.factor(datum.KO2$Sex) #Change to factor
          datum.KO2$Pop = as.factor(datum.KO2$Pop) #Change to factor
          
          #Relevel group variable to put in the desired order for plotting
          datum.KO2$Pop.sex<- factor(datum.KO2$Pop.sex,
                                                  levels = c("Female SD", "Male SD","Female BR", "Male BR",
                                                             "Female BOB", "Male BOB", "Female SH", "Male SH"))
          
          #Relevel group variable to put in the desired order for plotting
          datum.KO2$Pop<- factor(datum.KO2$Pop,
                                levels = c("SD", "BR","BOB", "SH"))
          
          
          
          #Rename columns to easier names to remember
          colnames(datum.KO2)[c(4,5)] <- c("Time", "LOE")
          
          #Refactor time column 
          datum.KO2$Time <- as.numeric(as.character(datum.KO2$Time))
          
          str(datum.KO2) #Check variable encoding
          
          
          #Population summary
            datum.KO.pop.mean <- datum.KO2 |> 
              filter(Group != "Control") |>
              filter(LOE != "NA") |>
              group_by(Pop, Time) |> 
              summarise(mean_KO = mean(LOE) |> round(2),
                        sd_KO = sd(LOE) |> round(2),
                        n = n(),
                        iqr = IQR(LOE, na.rm=TRUE),
                        range = paste(range(LOE) |> round(2), collapse = ' - ')
              ) |> 
              mutate(mean_text = glue('In {Pop}, the mean KO at {Time} hours was {number(mean_KO, accuracy = 0.01)} individuals out of 10')) |>
              mutate(se_KO = sd_KO/sqrt(n)) 
            datum.KO.pop.mean$se_KO <- round(datum.KO.pop.mean$se_KO, 2) #Round se column to 2 digits
          
          #Sex summary
            datum.KO.sex.mean <- datum.KO2 |>
              filter(Group != "Control") |>
              filter(LOE != "NA") |>
              group_by(Sex, Time) |> 
              summarise(mean_KO = mean(LOE) |> round(2),
                        sd_KO = sd(LOE) |> round(2),
                        n = n(),
                        iqr = IQR(LOE, na.rm=TRUE),
                        range = paste(range(LOE) |> round(2), collapse = ' - ')
              ) |> 
              mutate(mean_text = glue('In {Sex}s, the mean KO at {Time} hours was {number(mean_KO, accuracy = 0.01)} individuals out of 10')) |>
              mutate(se_KO = sd_KO/sqrt(n)) 
            datum.KO.sex.mean$se_KO <- round(datum.KO.sex.mean$se_KO, 2) #Round se column to 2 digits
          
          #Pop.sex summary
            datum.KO.popsex.mean <- datum.KO2 |> 
              filter(Group != "Control") |>
              filter(LOE != "NA") |>
              group_by(Pop.sex, Time) |> 
              summarise(mean_KO = mean(LOE) |> round(2),
                        sd_KO = sd(LOE) |> round(2),
                        n = n(),
                        iqr = IQR(LOE, na.rm=TRUE),
                        range = paste(range(LOE) |> round(2), collapse = ' - ')
              ) |> 
              mutate(mean_text = glue('In {Pop.sex}s, the mean KO at {Time} hours was {number(mean_KO, accuracy = 0.01)} individuals out of 10')) |>
              mutate(se_KO = sd_KO/sqrt(n)) 
            datum.KO.popsex.mean$se_KO <- round(datum.KO.popsex.mean$se_KO, 2) #Round se column to 2 digits
          
            
        ##Control data 
            #Population summary
            datum.KO.pop.mean.control <- datum.KO2 |> 
              filter(Group == "Control") |>
              filter(LOE != "NA") |>
              group_by(Pop, Time) |> 
              summarise(mean_KO = mean(LOE) |> round(2),
                        sd_KO = sd(LOE) |> round(2),
                        n = n(),
                        iqr = IQR(LOE, na.rm=TRUE),
                        range = paste(range(LOE) |> round(2), collapse = ' - ')
              ) |> 
              mutate(mean_text = glue('In the {Pop} controls, the mean KO at {Time} hours was {number(mean_KO, accuracy = 0.01)} individuals out of 10')) |>
              mutate(se_KO = sd_KO/sqrt(n)) 
            datum.KO.pop.mean.control$se_KO <- round(datum.KO.pop.mean.control$se_KO, 2) #Round se column to 2 digits
            
            #Sex summary
            datum.KO.sex.mean.control <- datum.KO2 |>
              filter(Group == "Control") |>
              filter(LOE != "NA") |>
              group_by(Sex, Time) |> 
              summarise(mean_KO = mean(LOE) |> round(2),
                        sd_KO = sd(LOE) |> round(2),
                        n = n(),
                        iqr = IQR(LOE, na.rm=TRUE),
                        range = paste(range(LOE) |> round(2), collapse = ' - ')
              ) |> 
              mutate(mean_text = glue('In control {Sex}s, the mean KO at {Time} hours was {number(mean_KO, accuracy = 0.01)} individuals out of 10')) |>
              mutate(se_KO = sd_KO/sqrt(n)) 
            datum.KO.sex.mean.control$se_KO <- round(datum.KO.sex.mean.control$se_KO, 2) #Round se column to 2 digits
            
            
            #Sex summary
            datum.KO.sex.mean.control <- datum.KO2 |>
              filter(Group == "Control") |>
              filter(LOE != "NA") |>
              group_by(Sex, Time) |> 
              summarise(mean_KO = mean(LOE) |> round(2),
                        sd_KO = sd(LOE) |> round(2),
                        n = n(),
                        iqr = IQR(LOE, na.rm=TRUE),
                        range = paste(range(LOE) |> round(2), collapse = ' - ')
              ) |> 
              mutate(mean_text = glue('In control {Sex}s, the mean KO at {Time} hours was {number(mean_KO, accuracy = 0.01)} individuals out of 10')) |>
              mutate(se_KO = sd_KO/sqrt(n)) 
            datum.KO.sex.mean.control$se_KO <- round(datum.KO.sex.mean.control$se_KO, 2) #Round se column to 2 digits
        


### Prep and summarize Survival data
      
      #Relabel sex factor
      datum.surv %>% 
        mutate(Sex = fct_recode(Sex, "Female" = "F",
                                "Male" = "M")) -> datum.surv
      
      #Combine sex and population factors into a Pop.sex factor
      datum.surv$Pop.sex <- paste(datum.surv$Sex, datum.surv$Pop)
      
      #Relevel group variable to put in the desired order for plotting
      datum.surv$Pop.sex<- factor(datum.surv$Pop.sex,
                           levels = c("Female SD", "Male SD","Female BR", "Male BR",
                                      "Female BOB", "Male BOB", "Female SH", "Male SH"))
      
      #Relevel group variable to put in the desired order for plotting
      datum.surv$Pop<- factor(datum.surv$Pop,
                         levels = c("SD", "BR","BOB", "SH"))
      
      str(datum.surv) #Check data coding before proceeding
      
      
      #Summarize data for plotting
      #Population summary
        datum.surv.pop.mean <- datum.surv |> 
          filter(Replicate != "control")|>
          group_by(Pop, Hours) |> 
          summarise(mean_surv = mean(Surv) |> round(2),
                    n = n(),
                    iqr = IQR(Surv),
                    range = paste(range(Surv) |> round(2), collapse = ' - ')
          ) |> 
          mutate(mean_text = glue('In {Pop}, the mean survival at {Hours} hours was {number(mean_surv, accuracy = 0.01)} individuals out of 10'))
        
      #Sex summary
        datum.surv.sex.mean <- datum.surv |> 
          filter(Replicate != "control")|>
          group_by(Sex, Hours) |> 
          summarise(mean_surv = mean(Surv) |> round(2),
                    n = n(),
                    iqr = IQR(Surv),
                    range = paste(range(Surv) |> round(2), collapse = ' - ')
          ) |> 
          mutate(mean_text = glue('In {Sex}s, the mean survival at {Hours} hours was {number(mean_surv, accuracy = 0.01)} individuals out of 10'))
        
      #Pop.sex summary
        datum.surv.popsex.mean <- datum.surv |>
          filter(Replicate != "control")|>
          group_by(Pop.sex, Pop, Sex, Hours) |> 
          summarise(mean_surv = mean(Surv) |> round(2),
                    n = n(),
                    iqr = IQR(Surv),
                    range = paste(range(Surv) |> round(2), collapse = ' - ')
          ) |> 
          mutate(mean_text = glue('In {Pop} {Sex}s, the mean survival at {Hours} hours was {number(mean_surv, accuracy = 0.01)} individuals out of 10'))
      
      

      
      
### Summarize time to anoxia data
      #Summarize data for plotting
      #Population summary
      datum.tua.pop.mean <- datum.surv |> 
        filter(Replicate != "control")|>
        filter(Hours != "control") |>
        group_by(Pop) |> 
        summarise(mean_tua = mean(Time_minutes) |> round(2),
                  n = n(),
                  iqr = IQR(Time_minutes),
                  range = paste(range(Time_minutes) |> round(2), collapse = ' - ')
        ) |> 
        mutate(mean_text = glue('In {Pop}, the mean time to anoxia was {number(mean_tua, accuracy = 0.01)} minutes'))
      
      #Sex summary
      datum.tua.sex.mean <- datum.surv |>
        filter(Replicate != "control")|>
        filter(Hours != "control") |>
        group_by(Sex) |> 
        summarise(mean_tua = mean(Time_minutes) |> round(2),
                  n = n(),
                  iqr = IQR(Time_minutes),
                  range = paste(range(Time_minutes) |> round(2), collapse = ' - ')
        ) |> 
        mutate(mean_text = glue('In {Sex}s, the mean time to anoxia was {number(mean_tua, accuracy = 0.01)} minutes'))
      
      #Pop.sex summary
      datum.tua.popsex.mean <- datum.surv |>
        filter(Replicate != "control")|>
        filter(Hours != "control") |>
        group_by(Pop.sex, Pop, Sex) |> 
        summarise(mean_tua = mean(Time_minutes) |> round(2),
                  n = n(),
                  iqr = IQR(Time_minutes),
                  range = paste(range(Time_minutes) |> round(2), collapse = ' - ')
        ) |> 
        mutate(mean_text = glue('In {Pop} {Sex}s, the mean time to anoxia was {number(mean_tua, accuracy = 0.01)} minutes'))
      
#Color pallete tweaking for ggplot (optional)
      br_pal <- met.brewer("Signac")
      br_pal2 <- met.brewer("Renoir")
      my_pal <- c(br_pal2[c(8,6)], br_pal[c(3,1)], br_pal2[c(2,4, 12,11)])
      # just for displaying old and new palette - not required for solution
      show_col(br_pal)
      show_col(br_pal2)
      show_col(my_pal)
      
      
      #Color pallete tweaking for ggplot (optional)
      br_pal <- met.brewer("Signac")
      br_pal2 <- met.brewer("Renoir")
      my_pal2 <- c(br_pal2[8], br_pal[3], br_pal2[c(2,12)])
      # just for displaying old and new palette - not required for solution
      show_col(br_pal)
      show_col(br_pal2)
      show_col(my_pal2)
      
      #Color pallete tweaking for ggplot (optional)
      br_pal3 <- pokepal(pokemon = "crawdaunt")
      my_pal3 <- c(br_pal3[c(11,4)])
      # just for displaying old and new palette - not required for solution
      show_col(br_pal3)
      show_col(my_pal3)

      
#### KO curves and multiple variable models  ####
    
        
    #Make individual replicate curves
        KOcurves <- datum.KO2 |>
        filter(Group != "Control") |>
        ggplot(aes(x=Time, y=LOE, group=Replicate.ID, color=Pop.sex)) +
          geom_line_interactive(size=1, alpha=1)+
          geom_point_interactive()+
          facet_wrap(~Pop,  nrow=4, strip.position = "left")+
          scale_y_reverse(name="Number of copepods with LOE (out of 10)", breaks = seq(0, 10, by = 1))+
          scale_x_continuous(name="Hours post plateau", breaks = seq(0, 6, by = 1), position="bottom")+
          xlab("Hours post plateau")+
          scale_color_manual("Groups (A, B):",values = my_pal) +
          theme(axis.text.x = element_text(size = 11),
                axis.title = element_text(size = 13),
                axis.text.y = element_text(size=10),
                legend.position = "none", legend.direction = "horizontal", strip.placement = 'outside', strip.text = element_text(size = 14))
        KOcurves
        
        #Export plot as jpeg
        jpeg(filename = "Individual KO curves.jpg", width = 5, height = 7, units = "in", res = 300)
        KOcurves
        dev.off()
        
        
    #Experimental data   
      #Make interactive plot for population
        KO.by.pop <- datum.KO.pop.mean |>
          ggplot(aes(x=Time, y=mean_KO, col=Pop))+
          geom_point_interactive(size = 6, aes(tooltip = mean_text)) +
          geom_line_interactive(linewidth=2)+
          geom_errorbar(aes(ymax = mean_KO + se_KO, 
                            ymin = mean_KO - se_KO),
                        width=0.4)+
          scale_x_continuous(name="Hours post plateau", breaks = seq(0, 6, by = 1), position="bottom")+
          scale_y_reverse(name="Copepods with LOE (out of 10)", breaks = seq(0, 10, by = 1))+
          scale_color_manual("Populations:",values = my_pal2)+
          theme(legend.position = "bottom", legend.direction = "horizontal")+
          ggtitle(label = "6 hours")
        KO.by.pop
        
      #Make interactive plot for sex
        KO.by.sex <- datum.KO.sex.mean |>
          ggplot(aes(x=Time, y=mean_KO, col=Sex))+
          geom_point_interactive(size = 6, aes(tooltip = mean_text)) +
          geom_line_interactive(linewidth=2)+
          geom_errorbar(aes(ymax = mean_KO + se_KO, 
                            ymin = mean_KO - se_KO),
                        width=0.4)+
          scale_x_continuous(name="Hours post plateau", breaks = seq(0, 6, by = 1), position="bottom")+
          scale_y_reverse(name="Copepods with LOE (out of 10)", breaks = seq(0, 10, by = 1), limits = c(10, 0))+
          scale_color_manual("Sexes:",values = my_pal3)+
          theme(legend.position = "bottom", legend.direction = "horizontal")+
          ggtitle(label = "6 hours")
        KO.by.sex
        
      #Make interactive plot for population and sex
        KO.by.popsex <- datum.KO.popsex.mean |>
          ggplot(aes(x=Time, y=mean_KO, col=Pop.sex))+
          geom_point_interactive(size = 6, aes(tooltip = mean_text)) +
          geom_line_interactive(linewidth=2)+
          geom_errorbar(aes(ymax = mean_KO + se_KO, 
                            ymin = mean_KO - se_KO),
                        width=0.4)+
          scale_x_continuous(name="Hours post plateau", breaks = seq(0, 6, by = 1), position="bottom")+
          scale_y_reverse(name="Copepods with LOE (out of 10)", breaks = seq(0, 10, by = 1), limits = c(10, 0))+
          scale_color_manual("Groups:",values = my_pal)+
          theme(legend.position = "bottom", legend.direction = "horizontal", axis.title.x = element_text(vjust=14),
                axis.title.y = element_text(size=12))+
          ggtitle(label = "6 hours")
        KO.by.popsex
        
        
    ##Control data
      #Make interactive plot for population
        KO.by.pop.control <- datum.KO.pop.mean.control |>
          ggplot(aes(x=Time, y=mean_KO, col=Pop))+
          geom_point_interactive(size = 6, aes(tooltip = mean_text), alpha=0.5) +
          geom_line_interactive(linewidth=2)+
          geom_errorbar(aes(ymax = mean_KO + se_KO, 
                            ymin = mean_KO - se_KO),
                        width=0.4)+
          scale_x_continuous(name="Hours post plateau", breaks = seq(0, 6, by = 1), position="bottom")+
          scale_y_reverse(name="Copepods with LOE (out of 10)", breaks = seq(0, 10, by = 1), limits = c(10, 0))+
          scale_color_manual("Populations:",values = my_pal2)+
          theme(legend.position = "bottom", legend.direction = "horizontal",
                title = element_text(size=11))+
          ggtitle(label = "Control - 6 hours")
        KO.by.pop.control
        
        #Make interactive plot for sex
        KO.by.sex.control <- datum.KO.sex.mean.control |>
          ggplot(aes(x=Time, y=mean_KO, col=Sex))+
          geom_point_interactive(size = 6, aes(tooltip = mean_text), alpha=0.5) +
          geom_line_interactive(linewidth=2)+
          geom_errorbar(aes(ymax = mean_KO + se_KO, 
                            ymin = mean_KO - se_KO),
                        width=0.4)+
          scale_x_continuous(name="Hours post plateau", breaks = seq(0, 6, by = 1), position="bottom")+
          scale_y_reverse(name="Copepods with LOE (out of 10)", breaks = seq(0, 10, by = 1), limits = c(10, 0))+
          scale_color_manual("Sexes:",values = my_pal3)+
          theme(legend.position = "bottom", legend.direction = "horizontal",
                title = element_text(size=11))+
          ggtitle(label = "Control - 6 hours")
        KO.by.sex.control
        
        #Make interactive plot for population and sex
        KO.by.popsex.control <- datum.KO2 |>
          filter(Group == "Control") |>
          ggplot(aes(x=Time, y=LOE, col=Pop.sex))+
          geom_point_interactive(size = 6) +
          geom_line_interactive(linewidth=2)+
          scale_x_continuous(name="Hours post plateau", breaks = seq(0, 6, by = 1), position="bottom")+
          scale_y_reverse(name="Copepods with LOE (out of 10)", breaks = seq(0, 10, by = 1), limits = c(10,0))+
          scale_color_manual("Groups:",values = my_pal)+
          theme(legend.position = "bottom", legend.direction = "horizontal", axis.title.x = element_text(vjust=14),
                title = element_text(size=11), axis.title.y = element_text(size=11))+
          ggtitle(label = "Control - 6 hours")
        KO.by.popsex.control
        
        
## Modeling effect of time spent at 0 on LOE  
        
      #Is there a significant difference in the effect of time on LOE between the different populations?
        #Model looks for effect of time and pop and their interaction on LOE
        #Model includes random effect of sex to control for non-independence of data coming from different sexes
        #poisson distribution link function used because it's count data in the response variable
            mod.1 <- glmer(LOE~Time*Pop + (1|Sex), data=subset(datum.KO2, Group != "Control"), family = poisson)
            summary(mod.1)
            comp.1 <- emmeans(mod.1, pairwise~Pop)
            comp.1
            #exponentiate the effect size for interaction to get it back into odds instead of log odds
            comp.1.contrasts.p <- as.data.frame(comp.1$contrasts) #With p-values
            comp.1.contrasts.ci <- as.data.frame(confint(comp.1$contrasts)) #With CIs
            
            write.csv(comp.1$emmeans, file = "Time effect on KO - Among Pop comparison means.csv", row.names = FALSE)
            write.csv(comp.1.contrasts.p, file = "Time effect on KO - Among Pop comparison.csv", row.names = FALSE) 
            write.csv(comp.1.contrasts.ci, file = "Time effect on KO - Among Pop comparison CIs.csv", row.names = FALSE)
        
      #Is there a significant difference in the effect of time on LOE between the different population and sex groupings?
        #Model looks for effect of time and grouping and their interaction on LOE
        #poisson distribution link function used because it's count data in the response variable
            mod.2 <- glm(LOE~Time*Pop.sex, data=subset(datum.KO2, Group != "Control"), family = poisson)
            summary(mod.2)
            comp.2 <- emmeans(mod.2, pairwise~Pop.sex)
            comp.2
            #exponentiate the effect size for interaction to get it back into odds instead of log odds
            comp.2.contrasts.p <- as.data.frame(comp.2$contrasts) #With p-values
            comp.2.contrasts.ci <- as.data.frame(confint(comp.2$contrasts)) #With CIs
            
            write.csv(comp.2$emmeans, file = "Time effect on KO - Among Popsex comparison means.csv", row.names = FALSE)
            write.csv(comp.2.contrasts.p, file = "Time effect on KO - Among PopSex Grouping comparison .csv", row.names = FALSE) #Save final frame as a csv
            write.csv(comp.2.contrasts.ci, file = "Time effect on KO - Among PopSex Grouping comparison CIs.csv", row.names = FALSE) #Save final frame as a csv
    
    #Is there a significant difference in the effect of time on LOE between males and females?
      #Model looks for effect of time and sex and their interaction on LOE
      #Model includes random effect of population to control for non-independence of data coming from different pops.
      #poisson distribution link function used because it's count data in the response variable
          mod.3 <- glmer(LOE~Time*Sex + (1|Pop), data=subset(datum.KO2, Group != "Control"), family=poisson)
          summary(mod.3)
          comp.3 <- emmeans(mod.3, pairwise~Sex)
          comp.3
          #exponentiate the effect size for interaction to get it back into odds instead of log odds
          exp(-0.11708)
          exp(confint(mod.3))
          
          write.csv(comp.3$emmeans, file = "Time effect on KO - Between Sexes comparison means.csv", row.names = FALSE)
          write.csv(summary(mod.3)$coefficients, file = "Time effect on KO - Between Sexes comparions.csv") #Export result as .csv for supplement
          write.csv(confint(mod.3), file = "Time effect on KO - Between Sexes comparions CIs.csv") #Export result as .csv for supplement
    
          
          
      #### Does time spent in anoxia affect the rate of LOE in controls? 
          #Using zeroinflated poisson model because nearly all values in data are zero
          datum.KO2.controls <- subset(datum.KO2, Group == "Control")
          
          mod.KO.controls <- zeroinfl(LOE~Time, data = datum.KO2.controls)
          summary(mod.KO.controls)
          
          write.csv(summary(mod.KO.controls)$coefficients, file = "Time effect on KO - Control comparions.csv") #Export result as .csv for supplement
          write.csv(confint(mod.KO.controls), file = "Time effect on KO - Control comparions CIs.csv") #Export result as .csv for supplement
      
####  Survival analysis ####
      
  #Population
      #Is there a significant difference among populations in each of the exposure times and controls?
          #6 hours
            mod.4 <- glm(Surv~Pop, data = subset(datum.surv, Hours == "6"), family=poisson)
            summary(mod.4)
            emmeans(mod.4, pairwise~Pop)
            #Export data
            comp.4 <- emmeans(mod.4, pairwise~Pop)
            write.csv(comp.4$contrasts, file = "Survival comparison by pop 6 hours contrasts.csv", row.names = FALSE)
            write.csv(confint(comp.4$contrasts), file = "Survival comparison by pop 6 hours contrasts CIs.csv", row.names = FALSE)
            
            #Without glm to get true means
            mod.4 <- lm(Surv~Pop, data = subset(datum.surv, Hours == "6"))
            comp.4 <- emmeans(mod.4, pairwise~Pop)
            write.csv(comp.4$emmeans, file = "Survival comparison by pop 6 hours emmeans.csv", row.names = FALSE)
            
          #15 hours
            mod.4b <- glm(Surv~Pop + Time_minutes, data = subset(datum.surv, Hours == "15"), family=poisson)
            summary(mod.4b)
            emmeans(mod.4b, pairwise~Pop)
            #Export data
            comp.4b <- emmeans(mod.4b, pairwise~Pop)
            write.csv(comp.4b$emmeans, file = "Survival comparison by pop 15 hours emmeans.csv", row.names = FALSE)
            write.csv(comp.4b$contrasts, file = "Survival comparison by pop 15 hours contrasts.csv", row.names = FALSE)
            write.csv(confint(comp.4b$contrasts), file = "Survival comparison by pop 15 hours contrasts CIs.csv", row.names = FALSE)
            
            #Without glm to get true means
            mod.4b <- lm(Surv~Pop, data = subset(datum.surv, Hours == "15"))
            comp.4b <- emmeans(mod.4b, pairwise~Pop)
            write.csv(comp.4b$emmeans, file = "Survival comparison by pop 15 hours emmeans.csv", row.names = FALSE)
          
          #24 hours
            mod.4c <- glm(Surv~Pop, data = subset(datum.surv, Hours == "24"), family=poisson)
            summary(mod.4c)
            emmeans(mod.4c, pairwise~Pop)
            #Export data
            comp.4c <- emmeans(mod.4c, pairwise~Pop)
            write.csv(comp.4c$emmeans, file = "Survival comparison by pop 24 hours emmeans.csv", row.names = FALSE)
            write.csv(comp.4c$contrasts, file = "Survival comparison by pop 24 hours contrasts.csv", row.names = FALSE)
            write.csv(confint(comp.4c$contrasts), file = "Survival comparison by pop 24 hours contrasts CIs.csv", row.names = FALSE)
            
            #Without glm to get true means
            mod.4c <- lm(Surv~Pop, data = subset(datum.surv, Hours == "24"))
            comp.4c <- emmeans(mod.4c, pairwise~Pop)
            write.csv(comp.4c$emmeans, file = "Survival comparison by pop 24 hours emmeans.csv", row.names = FALSE)
            
          #24 hour control 
            mod.4d <- glm(Surv~Pop, data = subset(datum.surv, Hours == "control"), family=poisson)
            summary(mod.4d)
            emmeans(mod.4d, pairwise~Pop)
            #Export data
            comp.4d <- emmeans(mod.4d, pairwise~Pop)
            write.csv(comp.4d$emmeans, file = "Survival comparison by pop control 24 hours emmeans.csv", row.names = FALSE)
            write.csv(comp.4d$contrasts, file = "Survival comparison by pop control 24 hours contrasts.csv", row.names = FALSE)
            write.csv(confint(comp.4d$contrasts), file = "Survival comparison by pop control 24 hours contrasts CIs.csv", row.names = FALSE)
            
            #Without glm to get true means
            mod.4d <- lm(Surv~Pop, data = subset(datum.surv, Hours == "control"))
            comp.4d <- emmeans(mod.4d, pairwise~Pop)
            write.csv(comp.4d$emmeans, file = "Survival comparison by pop control 24 hours emmeans.csv", row.names = FALSE)
            
          #6 hour control
            mod.4e <- glm(Surv~Pop, data = subset(datum.surv, Hours == "control6"), family=poisson)
            summary(mod.4e)
            emmeans(mod.4e, pairwise~Pop)
            #Export data
            comp.4e <- emmeans(mod.4e, pairwise~Pop)
            write.csv(comp.4e$contrasts, file = "Survival comparison by pop control 6 hours contrasts.csv", row.names = FALSE)
            write.csv(confint(comp.4e$contrasts), file = "Survival comparison by pop control 6 hours contrasts CIs.csv", row.names = FALSE)
            
            #Without glm to get true means
            mod.4e <- lm(Surv~Pop, data = subset(datum.surv, Hours == "control6"))
            comp.4e <- emmeans(mod.4e, pairwise~Pop)
            write.csv(comp.4e$emmeans, file = "Survival comparison by pop control 6 hours emmeans.csv", row.names = FALSE)
      
      
  #Run this before you make plots        
  #Relevel group variable to put in the desired order for plotting
          datum.surv$Pop<- factor(datum.surv$Pop,
                         levels = c("SD", "BR","BOB", "SH"))
      
      
      
      
  #Make boxplots for 6 hrs, 15 hrs, 24 hrs, and controls by population
      survival.pop.6 <- datum.surv |>
        full_join(datum.surv.pop.mean) |>
        filter(Hours == "6") |>
        ggplot(aes(x=Pop, y=Surv, fill=Pop, data_id=Pop))+
        geom_boxplot_interactive(aes(
          tooltip = glue(
            '
        {levels(datum.surv$Pop)[Pop]}\n
        {n} Replicates\n
        Mean survival: {mean_surv}\n
        Range: {range}\n
        IQR: {iqr}
        '
          )))+
        geom_point_interactive()+
        stat_summary(fun=mean, geom="point", shape=15, size=4)+
        scale_y_continuous(name="Surviving copepods out of 10", breaks = seq(0, 10, by = 1))+
        scale_fill_manual("Groups:",values=my_pal2)+
        scale_color_manual(values=my_pal2)+
        theme(legend.position = "none", legend.direction = "horizontal", axis.title.x.bottom = element_blank(), 
              axis.title.y = element_text(size = 14))+
        ggtitle(label = "6 hours")+
        annotate("text", 1, -0.5, label = "a", size = 5)+
        annotate("text", 2, -0.5, label = "a", size = 5)+
        annotate("text", 3, -0.5, label = "a", size = 5)+
        annotate("text", 4, -0.5, label = "a", size = 5)
      survival.pop.6
      
      
      survival.pop.15 <- datum.surv |>
        full_join(datum.surv.pop.mean) |>
        filter(Hours == "15") |>
        ggplot(aes(x=Pop, y=Surv, fill=Pop, data_id=Pop))+
        geom_boxplot_interactive(aes(
          tooltip = glue(
            '
        {levels(datum.surv$Pop)[Pop]}\n
        {n} Replicates\n
        Mean survival: {mean_surv}\n
        Range: {range}\n
        IQR: {iqr}
        '
          )))+
        geom_point_interactive()+
        stat_summary(fun=mean, geom="point", shape=15, size=4)+
        scale_y_continuous(name="", breaks = seq(0, 10, by = 1))+
        scale_fill_manual("Groups:",values=my_pal2)+
        scale_color_manual(values=my_pal2)+
        theme(legend.position = "none", legend.direction = "horizontal", axis.title.x.bottom = element_blank())+
        ggtitle(label = "15 hours")+
        annotate("text", 1, -0.5, label = "a", size = 5)+
        annotate("text", 2, -0.5, label = "b", size = 5)+
        annotate("text", 3, -0.5, label = "c", size = 5)+
        annotate("text", 4, -0.5, label = "c", size = 5)
      survival.pop.15
      
      
      survival.pop.24 <- datum.surv |>
        full_join(datum.surv.pop.mean) |>
        filter(Hours == "24") |>
        ggplot(aes(x=Pop, y=Surv, fill=Pop, data_id=Pop))+
        geom_boxplot_interactive(aes(
          tooltip = glue(
            '
        {levels(datum.surv$Pop)[Pop]}\n
        {n} Replicates\n
        Mean survival: {mean_surv}\n
        Range: {range}\n
        IQR: {iqr}
        '
          )))+
        geom_point_interactive()+
        stat_summary(fun=mean, geom="point", shape=15, size=4)+
        scale_y_continuous(name="", breaks = seq(0, 10, by = 1), limits=c(-0.5,10))+
        scale_fill_manual("Groups:",values=my_pal2)+
        scale_color_manual(values=my_pal2)+
        theme(legend.position = "none", legend.direction = "horizontal", axis.title.x.bottom = element_blank())+
        ggtitle(label = "24 hours")+
        annotate("text", 1, -0.5, label = "a", size = 5)+
        annotate("text", 2, -0.5, label = "b", size = 5)+
        annotate("text", 3, -0.5, label = "a", size = 5)+
        annotate("text", 4, -0.5, label = "a", size = 5)
      survival.pop.24
      
      
      survival.pop.control.24 <- datum.surv |>
        full_join(datum.surv.pop.mean) |>
        filter(Hours == "control") |>
        ggplot(aes(x=Pop, y=Surv, fill=Pop, data_id=Pop))+
        geom_boxplot_interactive(aes(
          tooltip = glue(
            '
        {levels(datum.surv$Pop)[Pop]}\n
        {n} Replicates\n
        Mean survival: {mean_surv}\n
        Range: {range}\n
        IQR: {iqr}
        '
          )))+
        geom_point_interactive()+
        stat_summary(fun=mean, geom="point", shape=15, size=4)+
        scale_y_continuous(name="", breaks = seq(0, 10, by = 1))+
        scale_fill_manual("Groups:",values=my_pal2)+
        scale_color_manual(values=my_pal2)+
        theme(legend.position = "none", legend.direction = "horizontal", axis.title.x.bottom = element_blank(),
              axis.title.y = element_text(size = 8), title = element_text(size=11))+
        ggtitle(label = "Control - 24 hours")+
        annotate("text", 1, -0.5, label = "a", size = 5)+
        annotate("text", 2, -0.5, label = "a", size = 5)+
        annotate("text", 3, -0.5, label = "a", size = 5)+
        annotate("text", 4, -0.5, label = "a", size = 5)
      survival.pop.control.24
      
      
      survival.pop.control.6 <- datum.surv |>
        full_join(datum.surv.pop.mean) |>
        filter(Hours == "control6") |>
        ggplot(aes(x=Pop, y=Surv, fill=Pop, data_id=Pop))+
        geom_boxplot_interactive(aes(
          tooltip = glue(
            '
        {levels(datum.surv$Pop)[Pop]}\n
        {n} Replicates\n
        Mean survival: {mean_surv}\n
        Range: {range}\n
        IQR: {iqr}
        '
          )))+
        geom_point_interactive()+
        stat_summary(fun=mean, geom="point", shape=15, size=4)+
        scale_y_continuous(name="Surviving copepods out of 10", breaks = seq(0, 10, by = 1), limits = c(-0.5, 10))+
        scale_fill_manual("Groups:",values=my_pal2)+
        scale_color_manual(values=my_pal2)+
        theme(legend.position = "none", legend.direction = "horizontal", axis.title.x.bottom = element_blank(), 
              title = element_text(size=11),
              axis.title.y = element_text(size = 12))+
        ggtitle(label = "Control - 6 hours")+
        annotate("text", 1, -0.5, label = "a", size = 5)+
        annotate("text", 2, -0.5, label = "a", size = 5)+
        annotate("text", 3, -0.5, label = "a", size = 5)+
        annotate("text", 4, -0.5, label = "a", size = 5)
      survival.pop.control.6
      
      #export figures as jpegs
      jpeg(filename = "KO and Survival by pop.jpg", width = 11, height = 5, units = "in", res = 300)
      KO.by.pop + (survival.pop.6 + survival.pop.15 + survival.pop.24)+
        plot_layout(widths = c(0.3, 0.95))+
        plot_annotation(tag_levels = 'A')
      dev.off()
      
      jpeg(filename = "KO and Survival by pop controls.jpg", width = 9, height = 4, units = "in", res = 300)
      KO.by.pop.control + (survival.pop.control.6 + survival.pop.control.24)+ 
        plot_layout(widths = c(0.4, 0.95))+
        plot_annotation(tag_levels = 'A')
      dev.off()
      
    #Make interactive figure for experimental trials
      ggiraph(
        ggobj = KO.by.pop + ((survival.pop.6 + survival.pop.15 + survival.pop.24)/(survival.pop.control.24+survival.pop.control.6))+ 
          plot_layout(widths = c(0.6, 0.95))+
          plot_annotation(tag_levels = 'A'),
        options = list(
          opts_hover_inv(css = "opacity:0.1;"),
          opts_tooltip(offx = 0, offy = 0, css = 'font-size: larger;')
        ),
        hover_css = "",
        height_svg = 9,
        width_svg = 16
      )
      
    
      
      
  #Sex
      #Is there a significant difference between males and females? 
        #6 hours
          mod.5 <- glm(Surv~Sex, data = subset(datum.surv, Hours == "6"), family=poisson)
          summary(mod.5)
          emmeans(mod.5, pairwise~Sex)
          #Export data
          comp.5 <- emmeans(mod.5, pairwise~Sex)
          write.csv(comp.5$contrasts, file = "Survival comparison by sex 6 hours contrasts.csv", row.names = FALSE)
          write.csv(confint(comp.5$contrasts), file = "Survival comparison by sex 6 hours contrasts CIs.csv", row.names = FALSE)
          
          #Without glm to get means
          mod.5 <- lm(Surv~Sex, data = subset(datum.surv, Hours == "6"))
          comp.5 <- emmeans(mod.5, pairwise~Sex)
          write.csv(comp.5$emmeans, file = "Survival comparison by sex 6 hours emmeans.csv", row.names = FALSE)
      
      
        #15 hours
          mod.5b <- glm(Surv~Sex + Time_minutes, data = subset(datum.surv, Hours == "15"), family=poisson)
          summary(mod.5b)
          emmeans(mod.5b, pairwise~Sex)
          #Export data
          comp.5b <- emmeans(mod.5b, pairwise~Sex)
          
          write.csv(comp.5b$contrasts, file = "Survival comparison by sex 15 hours contrasts.csv", row.names = FALSE)
          write.csv(confint(comp.5b$contrasts), file = "Survival comparison by sex 15 hours contrasts CIs.csv", row.names = FALSE)
      
          #Without glm to get means
          mod.5b <- lm(Surv~Sex, data = subset(datum.surv, Hours == "15"))
          comp.5b <- emmeans(mod.5b, pairwise~Sex)
          write.csv(comp.5b$emmeans, file = "Survival comparison by sex 15 hours emmeans.csv", row.names = FALSE)
      
        #24 hours
          mod.5c <- glm(Surv~Sex, data = subset(datum.surv, Hours == "24"), family=poisson)
          summary(mod.5c)
          emmeans(mod.5c, pairwise~Sex)
          #Export data
          comp.5c <- emmeans(mod.5c, pairwise~Sex)
          write.csv(comp.5c$contrasts, file = "Survival comparison by sex 24 hours contrasts.csv", row.names = FALSE)
          write.csv(confint(comp.5c$contrasts), file = "Survival comparison by sex 24 hours contrasts CIs.csv", row.names = FALSE)
      
          #Without glm to get means
          mod.5c <- lm(Surv~Sex, data = subset(datum.surv, Hours == "24"))
          comp.5c <- emmeans(mod.5c, pairwise~Sex)
          write.csv(comp.5c$emmeans, file = "Survival comparison by sex 24 hours emmeans.csv", row.names = FALSE)
          
          
        #24 hour control 
          mod.5d <- glm(Surv~Sex, data = subset(datum.surv, Hours == "control"), family=poisson)
          summary(mod.5d)
          emmeans(mod.5d, pairwise~Sex)
          #Export data
          comp.5d <- emmeans(mod.5d, pairwise~Sex)
          write.csv(comp.5d$emmeans, file = "Survival comparison by sex control 24 hours emmeans.csv", row.names = FALSE)
          write.csv(comp.5d$contrasts, file = "Survival comparison by sex control 24 hours contrasts.csv", row.names = FALSE)
          write.csv(confint(comp.5d$contrasts), file = "Survival comparison by sex control 24 hours contrasts CIs.csv", row.names = FALSE)
      
          #Without glm to get means
          mod.5d <- lm(Surv~Sex, data = subset(datum.surv, Hours == "control"))
          comp.5d <- emmeans(mod.5d, pairwise~Sex)
          write.csv(comp.5d$emmeans, file = "Survival comparison by sex control 24 hours emmeans.csv", row.names = FALSE)
      
        #6 hour control
          mod.5e <- glm(Surv~Sex, data = subset(datum.surv, Hours == "control6"), family=poisson)
          summary(mod.5e)
          emmeans(mod.5e, pairwise~Sex)
          #Export data
          comp.5e <- emmeans(mod.5e, pairwise~Sex)
          write.csv(comp.5e$contrasts, file = "Survival comparison by sex control 6 hours contrasts.csv", row.names = FALSE)
          write.csv(confint(comp.5e$contrasts), file = "Survival comparison by sex control 6 hours contrasts CIs.csv", row.names = FALSE)
          
          #Without glm to get means
          mod.5e <- lm(Surv~Sex, data = subset(datum.surv, Hours == "control6"))
          comp.5e <- emmeans(mod.5e, pairwise~Sex)
          write.csv(comp.5e$emmeans, file = "Survival comparison by sex control 6 hours emmeans.csv", row.names = FALSE)
      
      
      #Make boxplots for 6 hrs, 15 hrs, 24 hrs, and controls by sex
          survival.sex.6 <- datum.surv |>
            full_join(datum.surv.sex.mean) |>
            filter(Hours == "6") |>
            ggplot(aes(x=Sex, y=Surv, fill=Sex, data_id=Sex))+
            geom_boxplot_interactive(aes(
              tooltip = glue(
                '
            {levels(datum.surv$Sex)[Sex]}\n
            {n} Replicates\n
            Mean survival: {mean_surv}\n
            Range: {range}\n
            IQR: {iqr}
            '
              )))+
            geom_point_interactive()+
            stat_summary(fun=mean, geom="point", shape=15, size=4)+
            scale_y_continuous(name="Surviving copepods out of 10", breaks = seq(0, 10, by = 1))+
            scale_fill_manual("Sexes:",values=my_pal3)+
            theme(legend.position = "none", legend.direction = "horizontal", axis.title.x.bottom = element_blank(), 
                  axis.title.y = element_text(size = 9.5))+
            ggtitle(label = "6 hours")+
            annotate("text", 1, -0.5, label = "a", size = 5)+
            annotate("text", 2, -0.5, label = "a", size = 5)
          survival.sex.6
          
          
          survival.sex.15 <- datum.surv |>
            full_join(datum.surv.sex.mean) |>
            filter(Hours == "15") |>
            ggplot(aes(x=Sex, y=Surv, fill=Sex, data_id=Sex))+
            geom_boxplot_interactive(aes(
              tooltip = glue(
                '
            {levels(datum.surv$Sex)[Sex]}\n
            {n} Replicates\n
            Mean survival: {mean_surv}\n
            Range: {range}\n
            IQR: {iqr}
            '
              )))+
            geom_point_interactive()+
            stat_summary(fun=mean, geom="point", shape=15, size=4)+
            scale_y_continuous(name="", breaks = seq(0, 10, by = 1))+
            scale_fill_manual("Sexes:",values=my_pal3)+
            theme(legend.position = "none", legend.direction = "horizontal", axis.title.x.bottom = element_blank())+
            ggtitle(label = "15 hours")+
            annotate("text", 1, -0.5, label = "a", size = 5)+
            annotate("text", 2, -0.5, label = "b", size = 5)
          survival.sex.15
          
          
          survival.sex.24 <- datum.surv |>
            full_join(datum.surv.sex.mean) |>
            filter(Hours == "24") |>
            ggplot(aes(x=Sex, y=Surv, fill=Sex, data_id=Sex))+
            geom_boxplot_interactive(aes(
              tooltip = glue(
                '
            {levels(datum.surv$Sex)[Sex]}\n
            {n} Replicates\n
            Mean survival: {mean_surv}\n
            Range: {range}\n
            IQR: {iqr}
            '
              )))+
            geom_point_interactive()+
            stat_summary(fun=mean, geom="point", shape=15, size=4)+
            scale_y_continuous(name="", breaks = seq(0, 10, by = 1), limits=c(-0.5,10))+
            scale_fill_manual("Sexes:",values=my_pal3)+
            theme(legend.position = "none", legend.direction = "horizontal", axis.title.x.bottom = element_blank())+
            ggtitle(label = "24 hours")+
            annotate("text", 1, -0.5, label = "a", size = 5)+
            annotate("text", 2, -0.5, label = "b", size = 5)
          survival.sex.24
          
          
          survival.sex.control.24hr <- datum.surv |>
            full_join(datum.surv.sex.mean) |>
            filter(Hours == "control") |>
            ggplot(aes(x=Sex, y=Surv, fill=Sex, data_id=Sex))+
            geom_boxplot_interactive(aes(
              tooltip = glue(
                '
            {levels(datum.surv$Sex)[Sex]}\n
            {n} Replicates\n
            Mean survival: {mean_surv}\n
            Range: {range}\n
            IQR: {iqr}
            '
              )))+
            geom_point_interactive()+
            stat_summary(fun=mean, geom="point", shape=15, size=4)+
            scale_y_continuous(name="", breaks = seq(0, 10, by = 1))+
            scale_fill_manual("Sexes:",values=my_pal3)+
            theme(legend.position = "none", legend.direction = "horizontal", axis.title.x.bottom = element_blank(), 
                  title = element_text(size=11))+
            ggtitle(label = "Control - 24 hours")+
            annotate("text", 1, -0.5, label = "a", size = 5)+
            annotate("text", 2, -0.5, label = "a", size = 5)
          survival.sex.control.24hr
          
          
          survival.sex.control.6hr <- datum.surv |>
            full_join(datum.surv.sex.mean) |>
            filter(Hours == "control6") |>
            ggplot(aes(x=Sex, y=Surv, fill=Sex, data_id=Sex))+
            geom_boxplot_interactive(aes(
              tooltip = glue(
                '
            {levels(datum.surv$Sex)[Sex]}\n
            {n} Replicates\n
            Mean survival: {mean_surv}\n
            Range: {range}\n
            IQR: {iqr}
            '
              )))+
            geom_point_interactive()+
            stat_summary(fun=mean, geom="point", shape=15, size=4)+
            scale_y_continuous(name="Surviving copepods out of 10", breaks = seq(0, 10, by = 1), limits = c(-0.5, 10))+
            scale_fill_manual("Sexes:",values=my_pal3)+
            theme(legend.position = "none", legend.direction = "horizontal", axis.title.x.bottom = element_blank(),
                  axis.title.y = element_text(size = 11), title = element_text(size=11))+
            ggtitle(label = "Control - 6 hours")+
            annotate("text", 1, -0.5, label = "a", size = 5)+
            annotate("text", 2, -0.5, label = "a", size = 5)
          survival.sex.control.6hr
      
          
      #Export figure as jpeg
        jpeg(filename = "KO and Survival by sex.jpg", width = 11, height = 5, units = "in", res = 300)
        KO.by.sex + (survival.sex.6 + survival.sex.15 + survival.sex.24) + 
          plot_layout(widths = c(0.3, 0.95))+
          plot_annotation(tag_levels = 'A')
        dev.off()
        
        jpeg(filename = "KO and Survival by sex controls.jpg", width = 9, height = 4, units = "in", res = 300)
        KO.by.sex.control + (survival.sex.control.6hr + survival.sex.control.24hr) + 
          plot_layout(widths = c(0.4, 0.95))+
          plot_annotation(tag_levels = 'A')
        dev.off()
        
      
  
      #Make interactive figure 
        ggiraph(
          ggobj = KO.by.sex + (survival.sex.6 + survival.sex.15 + survival.sex.24) + plot_layout(widths = c(0.6, 0.95)),
          options = list(
            opts_hover_inv(css = "opacity:0.1;"),
            opts_tooltip(offx = 0, offy = 0, css = 'font-size: larger;')
          ),
          hover_css = "",
          height_svg = 9,
          width_svg = 16
        )
      
      
    #Population and sex
          #Is there a significant difference between males and females of each population? 
        #6 hours
        mod.6 <- lm(sqrt(Surv)~Pop.sex + Time_minutes, data = subset(datum.surv, Hours == "6"))
        summary(mod.6)
        emmeans(mod.6, pairwise~Pop.sex)
        #Export data
        comp.6 <- emmeans(mod.6, pairwise~Pop.sex)
        write.csv(comp.6$contrasts, file = "Survival comparison by population and sex 6 hours contrasts.csv", row.names = FALSE)
        write.csv(confint(comp.6$contrasts), file = "Survival comparison by population and sex 6 hours contrasts CIs.csv", row.names = FALSE)
        
        #Without square root to get means
        mod.6 <- lm(Surv~Pop.sex + Time_minutes, data = subset(datum.surv, Hours == "6"))
        emmeans(mod.6, pairwise~Pop.sex)
        comp.6 <- emmeans(mod.6, pairwise~Pop.sex)
        write.csv(comp.6$emmeans, file = "Survival comparison by population and sex 6 hours emmeans.csv", row.names = FALSE)
        
        
        #15 hours
        mod.6b <- lm(sqrt(Surv)~Pop.sex + Time_minutes, data = subset(datum.surv, Hours == "15"))
        summary(mod.6b)
        emmeans(mod.6b, pairwise~Pop.sex)
        #Export data
        comp.6b <- emmeans(mod.6b, pairwise~Pop.sex)
        write.csv(comp.6b$contrasts, file = "Survival comparison by population and sex 15 hours contrasts.csv", row.names = FALSE)
        write.csv(confint(comp.6b$contrasts), file = "Survival comparison by population and sex 15 hours contrasts CIs.csv", row.names = FALSE)
        
        #Without square root to get means
        mod.6b <- lm(Surv~Pop.sex + Time_minutes, data = subset(datum.surv, Hours == "15"))
        comp.6b <- emmeans(mod.6b, pairwise~Pop.sex)
        write.csv(comp.6b$emmeans, file = "Survival comparison by population and sex 15 hours emmeans.csv", row.names = FALSE)
        
        
        #24 hours
        mod.6c <- lm(sqrt(Surv)~Pop.sex, data = subset(datum.surv, Hours == "24"))
        summary(mod.6c)
        emmeans(mod.6c, pairwise~Pop.sex)
        #Export data
        comp.6c <- emmeans(mod.6c, pairwise~Pop.sex)
        write.csv(comp.6c$contrasts, file = "Survival comparison by population and sex 24 hours contrasts.csv", row.names = FALSE)
        write.csv(confint(comp.6c$contrasts), file = "Survival comparison by population and sex 24 hours contrasts CIs.csv", row.names = FALSE)
        
        #Without square root to get means
        mod.6c <- lm(Surv~Pop.sex, data = subset(datum.surv, Hours == "24"))
        comp.6c <- emmeans(mod.6c, pairwise~Pop.sex)
        write.csv(comp.6c$emmeans, file = "Survival comparison by population and sex 24 hours emmeans.csv", row.names = FALSE)
        
        #No stats on control at this level because one replicate each
        
        #Relevel group variable to put in the desired order for plotting
          datum$Pop.sex<- factor(datum$Pop.sex,
                                 levels = c("Female SD", "Male SD","Female BR", "Male BR",
                                            "Female BOB", "Male BOB", "Female SH", "Male SH"))
          
        #Make boxplots for 6 hrs, 15 hrs, 24 hrs, and controls by pop.sex
          survival.popsex.6 <- datum.surv |>
            full_join(datum.surv.popsex.mean) |>
            filter(Hours == "6") |>
            ggplot(aes(x=Pop.sex, y=Surv, fill=Pop.sex, data_id=Pop.sex))+
            geom_boxplot_interactive(aes(
              tooltip = glue(
                '
                {levels(datum.surv$Pop.sex)[Pop.sex]}\n
                {n} Replicates\n
                Mean survival: {mean_surv}\n
                Range: {range}\n
                IQR: {iqr}
                '
              )))+
            geom_point_interactive()+
            stat_summary(fun=mean, geom="point", shape=15, size=2.5)+
            scale_y_continuous(name="Surviving copepods out of 10", breaks = seq(0, 10, by = 1))+
            scale_fill_manual("Groups:",values=my_pal)+
            theme(legend.position = "none", legend.direction = "horizontal", axis.title.x.bottom = element_blank(), axis.text.x = element_text(size=11, angle=45, vjust=1, hjust=1), 
                  axis.title.y = element_text(size = 12))+
            ggtitle(label = "6 hours")+
            annotate("text", 1, -0.5, label = "a", size = 4)+
            annotate("text", 2, -0.5, label = "a", size = 4)+
            annotate("text", 3, -0.5, label = "a", size = 4)+
            annotate("text", 4, -0.5, label = "a", size = 4)+
            annotate("text", 5, -0.5, label = "ab", size = 4)+
            annotate("text", 6, -0.5, label = "b", size = 4)+
            annotate("text", 7, -0.5, label = "ab", size = 4)+
            annotate("text", 8, -0.5, label = "ab", size = 4)
          survival.popsex.6
          
          
          survival.popsex.15 <- datum.surv |>
            full_join(datum.surv.popsex.mean) |>
            filter(Hours == "15") |>
            ggplot(aes(x=Pop.sex, y=Surv, fill=Pop.sex, data_id=Pop.sex))+
            geom_boxplot_interactive(aes(
              tooltip = glue(
                '
                {levels(datum.surv$Pop.sex)[Pop.sex]}\n
                {n} Replicates\n
                Mean survival: {mean_surv}\n
                Range: {range}\n
                IQR: {iqr}
                '
              )))+
            geom_point_interactive()+
            stat_summary(fun=mean, geom="point", shape=15, size=2.5)+
            scale_y_continuous(name="", breaks = seq(0, 10, by = 1))+
            scale_fill_manual("Groups:",values=my_pal)+
            theme(legend.position = "none", legend.direction = "horizontal", axis.title.x.bottom = element_blank(), axis.text.x = element_text(size=11, angle=45, vjust=1, hjust=1))+
            ggtitle(label = "15 hours")+
            annotate("text", 1, -0.5, label = "ac", size = 4)+
            annotate("text", 2, -0.5, label = "ac", size = 4)+
            annotate("text", 3, -0.5, label = "b", size = 4)+
            annotate("text", 4, -0.5, label = "a", size = 4)+
            annotate("text", 5, -0.5, label = "ac", size = 4)+
            annotate("text", 6, -0.5, label = "c", size = 4)+
            annotate("text", 7, -0.5, label = "ac", size = 4)+
            annotate("text", 8, -0.5, label = "c", size = 4)
          survival.popsex.15
          
          
          survival.popsex.24 <- datum.surv |>
            full_join(datum.surv.popsex.mean) |>
            filter(Hours == "24") |>
            ggplot(aes(x=Pop.sex, y=Surv, fill=Pop.sex, data_id=Pop.sex))+
            geom_boxplot_interactive(aes(
              tooltip = glue(
                '
                {levels(datum.surv$Pop.sex)[Pop.sex]}\n
                {n} Replicates\n
                Mean survival: {mean_surv}\n
                Range: {range}\n
                IQR: {iqr}
                '
              )))+
            geom_point_interactive()+
            stat_summary(fun=mean, geom="point", shape=15, size=2.5)+
            scale_y_continuous(name="", breaks = seq(0, 10, by = 1), limits=c(-0.5,10))+
            scale_fill_manual("Groups:",values=my_pal)+
            theme(legend.position = "none", legend.direction = "horizontal", axis.title.x.bottom = element_blank(), axis.text.x = element_text(size=11, angle=45, vjust=1, hjust=1))+
            ggtitle(label = "24 hours")+
            annotate("text", 1, -0.5, label = "ab", size = 4)+
            annotate("text", 2, -0.5, label = "a", size = 4)+
            annotate("text", 3, -0.5, label = "b", size = 4)+
            annotate("text", 4, -0.5, label = "ab", size = 4)+
            annotate("text", 5, -0.5, label = "a", size = 4)+
            annotate("text", 6, -0.5, label = "a", size = 4)+
            annotate("text", 7, -0.5, label = "a", size = 4)+
            annotate("text", 8, -0.5, label = "a", size = 4)
          survival.popsex.24
          
          
          survival.popsex.control.24 <- datum.surv |>
            full_join(datum.surv.popsex.mean) |>
            filter(Hours == "control") |>
            ggplot(aes(x=Pop.sex, y=Surv, col=Pop.sex, data_id=Pop.sex))+
            geom_point_interactive(aes(
              tooltip = glue(
                '
                {levels(datum.surv$Pop.sex)[Pop.sex]}\n
                {n} Replicates\n
                Mean survival: {mean_surv}\n
                Range: {range}\n
                IQR: {iqr}
                '
              )), size =4.5, shape=16)+
            scale_y_continuous(name="", breaks = seq(0, 10, by = 1), limits = c(0,10))+
            scale_color_manual("Groups:",values=my_pal)+
            theme(legend.position = "none", legend.direction = "horizontal", axis.title.x.bottom = element_blank(), 
                  axis.text.x = element_text(size=11, angle=45, vjust=1, hjust=1))+
            ggtitle(label = "Control - 24 hours")
          survival.popsex.control.24
          
          
          survival.popsex.control.6 <- datum.surv |>
            full_join(datum.surv.popsex.mean) |>
            filter(Hours == "control6") |>
            ggplot(aes(x=Pop.sex, y=Surv, col=Pop.sex, data_id=Pop.sex))+
            geom_point_interactive(aes(
              tooltip = glue(
                '
                {levels(datum.surv$Pop.sex)[Pop.sex]}\n
                {n} Replicates\n
                Mean survival: {mean_surv}\n
                Range: {range}\n
                IQR: {iqr}
                '
              )), size =4.5, shape=16)+
            scale_y_continuous(name="Surviving copepods out of 10", breaks = seq(0, 10, by = 1), limits = c(0, 10))+
            scale_color_manual("Groups:",values=my_pal)+
            theme(legend.position = "none", legend.direction = "horizontal", axis.title.x.bottom = element_blank(), 
                  axis.text.x = element_text(size=11, angle=45, vjust=1, hjust=1), axis.title.y = element_text(size=12))+
            ggtitle(label = "Control - 6 hours")
          survival.popsex.control.6
          
          
          #Export figure as jpeg
          jpeg(filename = "KO and Survival by pop and sex.jpg", width = 11, height = 5, units = "in", res = 300)
          KO.by.popsex + (survival.popsex.6 + survival.popsex.15 + survival.popsex.24) + 
            plot_layout(widths = c(0.4, 1)) +
            plot_annotation(tag_levels = 'A')
          dev.off()
          
          jpeg(filename = "KO and Survival by pop and sex controls.jpg", width = 9, height = 4.5, units = "in", res = 300)
          KO.by.popsex.control + (survival.popsex.control.6 + survival.popsex.control.24) + 
            plot_layout(widths = c(0.4, 1)) +
            plot_annotation(tag_levels = 'A')
          dev.off()
          
          #/ (survival.popsex.control + survival.popsex.control)
          
          #Make interactive figure 
          ggiraph(
            ggobj = KO.by.popsex + (survival.popsex.6 + survival.popsex.15 + survival.popsex.24) + plot_layout(widths = c(0.5, 1)),
            options = list(
              opts_hover_inv(css = "opacity:0.1;"),
              opts_tooltip(offx = 0, offy = 0, css = 'font-size: larger;')
            ),
            hover_css = "",
            height_svg = 9,
            width_svg = 16
          )
      
    

      
 
#### Time until anoxia among populations and sexes ####
      #Analyze differences among groups and check for effect of rate at which groups reach anoxia on LOE 
          #Use datum.surv data frame since it has the KO test data within it (the 6 hours grouping).
      
      #Differences among groups 
      #Sex
          mod.7 <- lmer(Time_minutes~Sex + (1|Pop), data = datum.surv)
          summary(mod.7)
          emmeans(mod.7, pairwise~Sex)
          #Export data
          comp.7 <- emmeans(mod.7, pairwise~Sex)
          write.csv(comp.7$emmeans, file = "Time until anoxia by sex emmeans.csv", row.names = FALSE)
          write.csv(comp.7$contrasts, file = "Time until anoxia by sex contrasts.csv", row.names = FALSE)
          write.csv(confint(comp.7$contrasts), file = "Time until anoxia by sex contrasts CIs.csv", row.names = FALSE)
          
        #Make boxplot
          tua.sex <- datum.surv |>
            full_join(datum.tua.sex.mean) |>
            filter(Hours != "control") |>
            ggplot(aes(x=Sex, y=Time_minutes, fill=Sex, data_id=Sex))+
            geom_boxplot_interactive(aes(
              tooltip = glue(
                '
            {levels(datum.surv$Sex)[Sex]}\n
            {n} Replicates\n
            Mean time: {mean_tua}\n
            Range: {range}\n
            IQR: {iqr}
            '
              )))+
            geom_point_interactive()+
            geom_point_interactive(aes(x=Sex, y=mean_tua), color='black', shape=15, size=4, show.legend = F)+
            scale_y_continuous(name="Minutes", breaks = seq(0, 350, by = 25), limits = c(0, 350))+
            scale_fill_manual("Sexes:",values=my_pal3)+
            theme(legend.position = "none", legend.direction = "horizontal", axis.title.x.bottom = element_blank())+
            ggtitle(label = "Time until anoxia")+
            annotate("text", 1, 1, label = "a", size = 5)+
            annotate("text", 2, 1, label = "a", size = 5)
            
          tua.sex
      
      
      #Population
          mod.8 <- lmer(Time_minutes~Pop + (1|Sex), data = datum.surv)
          summary(mod.8)
          emmeans(mod.8, pairwise~Pop)
          #Export data
          comp.8 <- emmeans(mod.8, pairwise~Pop)
          write.csv(comp.8$emmeans, file = "Time until anoxia by Pop emmeans.csv", row.names = FALSE)
          write.csv(comp.8$contrasts, file = "Time until anoxia by Pop contrasts.csv", row.names = FALSE)
          write.csv(confint(comp.8$contrasts), file = "Time until anoxia by Pop contrasts CIs.csv", row.names = FALSE)
          
          
          #Relevel group variable to put in the desired order for plotting
          datum.surv$Pop<- factor(datum.surv$Pop,
                             levels = c("SD", "BR","BOB", "SH"))
        #Make boxplot
          tua.pop <- datum.surv |>
            full_join(datum.tua.pop.mean) |>
            filter(Hours != "control") |>
            ggplot(aes(x=Pop, y=Time_minutes, fill=Pop, data_id=Pop))+
            geom_boxplot_interactive(aes(
              tooltip = glue(
                '
            {levels(datum.surv$Pop)[Pop]}\n
            {n} Replicates\n
            Mean time: {mean_tua}\n
            Range: {range}\n
            IQR: {iqr}
            '
              )))+
            geom_point_interactive()+
            geom_point_interactive(aes(x=Pop, y=mean_tua), color='black', shape=15, size=4, show.legend = F)+
            scale_y_continuous(name="", breaks = seq(0, 350, by = 25), limits = c(0, 350))+
            scale_fill_manual("Populations:",values=my_pal2)+
            theme(legend.position = "none", legend.direction = "horizontal", axis.title.x.bottom = element_blank())+
            ggtitle(label = "")+
            annotate("text", 1, 1, label = "a", size = 5)+
            annotate("text", 2, 1, label = "a", size = 5)+
            annotate("text", 3, 1, label = "a", size = 5)+
            annotate("text", 4, 1, label = "a", size = 5)
          tua.pop
      
      
      #Population and sex
          mod.9 <- lm(Time_minutes~Pop.sex, data = datum.surv)
          summary(mod.9)
          emmeans(mod.9, pairwise~Pop.sex)
          #Export data
          comp.9 <- emmeans(mod.9, pairwise~Pop.sex)
          write.csv(comp.9$emmeans, file = "Time until anoxia by Pop and sex emmeans.csv", row.names = FALSE)
          write.csv(comp.9$contrasts, file = "Time until anoxia by Pop and sex contrasts.csv", row.names = FALSE)
          write.csv(confint(comp.9$contrasts), file = "Time until anoxia by Pop and sex contrasts CIs.csv", row.names = FALSE)
          
          
          #Make boxplot
          #Relevel group variable to put in the desired order for plotting
          datum.surv$Pop.sex<- factor(datum.surv$Pop.sex,
                                 levels = c("Female SD", "Male SD","Female BR", "Male BR",
                                            "Female BOB", "Male BOB", "Female SH", "Male SH"))
          #Make boxplot
          tua.popsex <- datum.surv |>
            full_join(datum.tua.popsex.mean) |>
            filter(Hours != "control") |>
            ggplot(aes(x=Pop.sex, y=Time_minutes, fill=Pop.sex, data_id=Pop.sex))+
            geom_boxplot_interactive(aes(
              tooltip = glue(
                '
            {levels(datum.surv$Pop.sex)[Pop.sex]}\n
            {n} Replicates\n
            Mean time: {mean_tua}\n
            Range: {range}\n
            IQR: {iqr}
            '
              )))+
            geom_point_interactive()+
            geom_point_interactive(aes(x=Pop.sex, y=mean_tua), shape=15, size=4, show.legend = F)+
            scale_y_continuous(name="", breaks = seq(0, 350, by = 25), limits = c(0, 350))+
            scale_fill_manual("Groups:",values=my_pal)+
            theme(legend.position = "none", legend.direction = "horizontal", axis.title.x.bottom = element_blank(),
                  axis.text.x = element_text(angle=45, hjust=1, vjust=1))+
            ggtitle(label = "")+
            annotate("text", 1, 1, label = "a", size = 5)+
            annotate("text", 2, 1, label = "a", size = 5)+
            annotate("text", 3, 1, label = "a", size = 5)+
            annotate("text", 4, 1, label = "a", size = 5)+
            annotate("text", 5, 1, label = "a", size = 5)+
            annotate("text", 6, 1, label = "a", size = 5)+
            annotate("text", 7, 1, label = "a", size = 5)+
            annotate("text", 8, 1, label = "a", size = 5)
          tua.popsex
      
      
      ##Combine plots into one figure
          #Export figure as jpeg
          jpeg(filename = "Time until anoxia among pops.jpg", width = 10, height = 6, units = "in", res = 300)
          ggarrange(tua.sex, tua.pop, tua.popsex,
                    nrow = 1,ncol = 3,
                    labels = c("A", "B", "C")
          ) 
          dev.off()
      
####  Effect of rate to anoxia on LOE?   ####
          
          
      #Does rate at which copepods reached anoxia change the effect of time on LOE? 
      #poisson distribution link function used because it's count data in the response variable
      mod.10 <- glmer(LOE~Time*Time.minutes + (1|Pop), data=datum.KO2, family = poisson)
      summary(mod.10)
      # Fixed effects:
      #   Estimate Std. Error z value Pr(>|z|)    
      # (Intercept)       -0.6994461  0.3660045  -1.911 0.056001 .  
      # Time               0.3370403  0.0617296   5.460 4.76e-08 ***
      #   Time.minutes       0.0069110  0.0020750   3.331 0.000867 ***
      #   Time:Time.minutes -0.0005040  0.0004557  -1.106 0.268680   
      # # ---
      
      exp(-0.0005040) #To get effect of time until plateau on time's effect on LOE (...whew!)
      confint(mod.10)
      
      write.csv(summary(mod.10)$coefficients, file = "TUA effect on KO.csv") #Export result as .csv for supplement
      write.csv(confint(mod.10), file = "TUA effect on KO CIs.csv") #Export result as .csv for supplement
      
      r.squaredGLMM(mod.10)
      
      #According to numbers above, effect of time on LOE decreases by 0.001x per extra minute it takes a group to reach anoxia, 
      #but this effect is not significant
    
      #Run this before making plots so pops are in correct order
      datum.KO$Pop<- factor(datum.KO$Pop,
                             levels = c("SD", "BR","BOB", "SH"))
      
      #Does rate to anoxia change the number of copepods with LOE at time point 1hr or time point 6hrs? 
      #Effect at hour 1
      #Controlling for pop differences
      mod.11 <- glmer(X1hr~Time.minutes + (1|Pop), data = datum.KO, family=poisson)
      summary(mod.11)  
      write.csv(summary(mod.11)$coefficients, file = "TUA effect on Survival at 1hr with pop.csv") #Export result as .csv for supplement
      write.csv(exp(confint(mod.11)), file = "TUA effect on Survival at 1hr with pop CIs.csv") #Export result as .csv for supplement
      r.squaredGLMM(mod.11)
      
      #Make plot
      time.1hr.pop <- ggplot(datum.KO, aes(x=Time.minutes, y=X1hr, color=Pop)) + 
        geom_point(size=4)+
        geom_smooth(method=lm, se=TRUE)+
        scale_x_continuous(name="Time until plateau in minutes", breaks = seq(50, 225, by = 25), limits = c(50, 225))+
        scale_y_continuous(name="Number of copepods with LOE at hour 1", breaks = seq(0, 10, by = 1), limits = c(0, 10))+
        scale_color_manual("Pop:",values=my_pal2)+
        theme(legend.position = "top", legend.direction = "horizontal", axis.title.y = element_text(size=11))+
        annotate("text", x = 125, y = 10, label =  bquote('p=0.094, R'^2*'=0.49'), size = 4, color ="black")
      time.1hr.pop
      
      #Without controlling for pop differences
      mod.11b <- glm(X1hr~Time.minutes, data = datum.KO, family=poisson)
      summary(mod.11b) 
      r.squaredGLMM(mod.11b)
      write.csv(summary(mod.11b)$coefficients, file = "TUA effect on KO at 1hr without pop.csv") #Export result as .csv for supplement
      write.csv(exp(confint(mod.11b)), file = "TUA effect on KO at 1hr without pop CIs.csv") #Export result as .csv for supplement
      
      #Make plot
      time.1hr <- ggplot(datum.KO, aes(x=Time.minutes, y=X1hr)) + 
        geom_point(size=4)+
        geom_smooth(method=lm, se=TRUE)+
        scale_x_continuous(name="Time until plateau in minutes", breaks = seq(50, 225, by = 25), limits = c(50, 225))+
        scale_y_continuous(name="Number of copepods with LOE at hour 1", breaks = seq(0, 10, by = 1), limits = c(0, 10))+
        theme(legend.position = "right", legend.direction = "vertical", axis.title.y = element_text(size=11))+
        annotate("text", x = 125, y = 10, label =  bquote('p=0.003, R'^2*'=0.14'), size = 4, color ="black")
      time.1hr
      
      #Effect at hour 6
      #Controlling for pop differences
      mod.12 <- glmer(X6hr~Time.minutes + (1|Pop), data = datum.KO, family=poisson)
      summary(mod.12)  
      r.squaredGLMM(mod.12)
      write.csv(summary(mod.12)$coefficients, file = "TUA effect on KO at 6hr with pop.csv") #Export result as .csv for supplement
      write.csv(exp(confint(mod.12)), file = "TUA effect on KO at 6hr with pop CIs.csv") #Export result as .csv for supplement
      
      #Make plot
      time.6hr.pop <- ggplot(datum.KO, aes(x=Time.minutes, y=X6hr, color=Pop)) + 
        geom_point(size=4)+
        geom_smooth(method=lm, se=TRUE)+
        scale_x_continuous(name="Time until plateau in minutes", breaks = seq(50, 225, by = 25), limits = c(50, 225))+
        scale_y_continuous(name="Number of copepods with LOE at hour 6", breaks = seq(0, 10, by = 1), limits = c(0, 10))+
        coord_cartesian(ylim = c(0,10))+
        scale_color_manual("Pop:",values=my_pal2)+
        theme(legend.position = "top", legend.direction = "horizontal", axis.title.y = element_text(size=11))+
        annotate("text", x = 200, y = 0, label =  bquote('p=0.351, R'^2*'=0.46'), size = 4, color ="black")
      time.6hr.pop
      
      #Without controlling for pop differences
      mod.12b <- glm(X6hr~Time.minutes, data = datum.KO, family=poisson)
      summary(mod.12b) 
      r.squaredGLMM(mod.12b)
      write.csv(summary(mod.12b)$coefficients, file = "TUA effect on KO at 6hr without pop.csv") #Export result as .csv for supplement
      write.csv(exp(confint(mod.12b)), file = "TUA effect on KO at 6hr without pop CIs.csv") #Export result as .csv for supplement
      
      #Make plot
      time.6hr <- ggplot(datum.KO, aes(x=Time.minutes, y=X6hr)) + 
        geom_point(size=4)+
        geom_smooth(method=lm, se=TRUE)+
        scale_x_continuous(name="Time until plateau in minutes", breaks = seq(50, 225, by = 25), limits = c(50, 225))+
        scale_y_continuous(name="Number of copepods with LOE at hour 6", breaks = seq(0, 10, by = 1), limits = c(0, 10))+
        coord_cartesian(ylim = c(0,10))+
        theme(legend.position = "right", legend.direction = "vertical", axis.title.y = element_text(size=11))+
        annotate("text", x = 200, y = 0, label =  bquote('p=0.030, R'^2*'=0.09'), size = 4, color ="black")
      time.6hr
      
      ##Combine plots into one figure
      jpeg(filename = "Time vs 1hr and 6hr LOE figure.jpg", width = 18, height = 4, units = "in", res = 300)
      ggarrange(time.1hr, time.1hr.pop, time.6hr, time.6hr.pop,
                nrow = 1,ncol = 4,
                labels = c("A", "B", "C", "D"), label.x = 0, label.y = 1
      ) 
      dev.off()
      
      
####Does time until anoxia affect survival? ####
      
    #At 6 hours
      #Without controlling for pop differences
      mod.13 <- glm(Surv~Time_minutes, data = subset(datum.surv, Hours == "6"), family=poisson)
      summary(mod.13)
      r.squaredGLMM(mod.13)
      write.csv(summary(mod.13)$coefficients, file = "TUA effect on KO.csv") #Export result as .csv for supplement
      write.csv(confint(mod.13), file = "TUA effect on KO CIs.csv") #Export result as .csv for supplement
      
      #With controlling for pop differences
      mod.13b <- glmer(Surv~Time_minutes + (1|Pop), data = subset(datum.surv, Hours == "6"), family=poisson)
      summary(mod.13b)
      r.squaredGLMM(mod.13b)
      
      write.csv(summary(mod.13b)$coefficients, file = "TUA effect on Survival 6 hours.csv") #Export result as .csv for supplement
      write.csv(confint(mod.13b), file = "TUA effect on Survival 6 hours CIs.csv") #Export result as .csv for supplement
      
    #At 15 hours
      #Without controlling for pop differences
      mod.14 <- glm(Surv~Time_minutes, data = subset(datum.surv, Hours == "15"), family=poisson)
      summary(mod.14)
      r.squaredGLMM(mod.14)
      
      exp(-0.008152) #=0.991881
      
      #With controlling for pop differences
      mod.14b <- glmer(Surv~Time_minutes + (1|Pop), data = subset(datum.surv, Hours == "15"), family=poisson)
      summary(mod.14b)
      r.squaredGLMM(mod.14b)
      
      write.csv(summary(mod.14b)$coefficients, file = "TUA effect on Survival 15 hours.csv") #Export result as .csv for supplement
      write.csv(confint(mod.14b), file = "TUA effect on Survival 15 hours CIs.csv") #Export result as .csv for supplement
      
      exp(-0.008757) #=0.9912812
      
    #At 24 hours
      #Without controlling for pop differences
      mod.15 <- glm(Surv~Time_minutes, data = subset(datum.surv, Hours == "24"), family=poisson)
      summary(mod.15)
      r.squaredGLMM(mod.15)
      
      #With controlling for pop differences
      mod.15b <- glmer(Surv~Time_minutes + (1|Pop), data = subset(datum.surv, Hours == "24"), family=poisson)
      summary(mod.15b)
      r.squaredGLMM(mod.15b)
      
      write.csv(summary(mod.15b)$coefficients, file = "TUA effect on Survival 24 hours.csv") #Export result as .csv for supplement
      write.csv(confint(mod.15b), file = "TUA effect on Survival 24 hours CIs.csv") #Export result as .csv for supplement
      
      
    #Run this before making plots so pops are in correct order
      datum.surv$Pop<- factor(datum.surv$Pop,
                            levels = c("SD", "BR","BOB", "SH"))
      
    ##Make plots
      #6 hours across all pops
          tua.surv.6 <- datum.surv |>
            filter(Hours == "6") |>
            ggplot(aes(x=Time_minutes, y=Surv)) + 
                geom_point(size=4)+
                geom_smooth(method=lm, se=TRUE)+
                scale_x_continuous(name="", breaks = seq(50, 225, by = 25), limits = c(50, 225))+
                scale_y_continuous(name="Number of surviving copepods", breaks = seq(0, 10, by = 1))+
                scale_color_manual("Pop:",values=my_pal2)+
                coord_cartesian(ylim = c(0,10))+
                theme(legend.position = "top", legend.direction = "horizontal", axis.title.y = element_text(size=11))+
                annotate("text", x = 75, y = 0, label =  bquote('p=0.317, R'^2*'=0.02'), size = 3, color ="black")+
                ggtitle(label = "6 hours - across all data")
          tua.surv.6
      #6 hours among pops
          tua.surv.6.pops <- datum.surv |>
            filter(Hours == "6") |>
            ggplot(aes(x=Time_minutes, y=Surv, col=Pop)) + 
            geom_point(size=4)+
            geom_smooth(method=lm, se=TRUE)+
            scale_x_continuous(name="", breaks = seq(50, 225, by = 25), limits = c(50, 225))+
            scale_y_continuous(name="", breaks = seq(0, 10, by = 1))+
            coord_cartesian(ylim = c(0,10))+
            scale_color_manual("Pop:",values=my_pal2)+
            theme(legend.position = "top", legend.direction = "horizontal", axis.title.y = element_text(size=11))+
            annotate("text", x = 75, y = 0, label =  bquote('p=0.317, R'^2*'=0.02'), size = 3, color ="black")+
            ggtitle(label = "6 hours - control for pops")
          tua.surv.6.pops
      #15 hours across all pops
          tua.surv.15 <- datum.surv |>
            filter(Hours == "15") |>
            ggplot(aes(x=Time_minutes, y=Surv)) + 
            geom_point(size=4)+
            geom_smooth(method=lm, se=TRUE)+
            scale_x_continuous(name="", breaks = seq(50, 225, by = 25), limits = c(50, 225))+
            scale_y_continuous(name="Number of surviving copepods", breaks = seq(0, 10, by = 1))+
            coord_cartesian(ylim = c(0,10))+
            scale_color_manual("Pop:",values=my_pal2)+
            theme(legend.position = "top", legend.direction = "horizontal", axis.title.y = element_text(size=11))+
            annotate("text", x = 75, y = 0, label =  bquote('p=0.0001, R'^2*'=0.29'), size = 3, color ="black")+
            ggtitle(label = "15 hours - across all data")
          tua.surv.15
      #15 hours among pops
          tua.surv.15.pops <- datum.surv |>
            filter(Hours == "15") |>
            ggplot(aes(x=Time_minutes, y=Surv, col=Pop)) + 
            geom_point(size=4)+
            geom_smooth(method=lm, se=TRUE)+
            scale_x_continuous(name="", breaks = seq(50, 225, by = 25), limits = c(50, 225))+
            scale_y_continuous(name="", breaks = seq(0, 10, by = 1))+
            coord_cartesian(ylim = c(0,10))+
            scale_color_manual("Pop:",values=my_pal2)+
            theme(legend.position = "top", legend.direction = "horizontal", axis.title.y = element_text(size=11))+
            annotate("text", x = 75, y = 0, label =  bquote('p<0.0001, R'^2*'=0.82'), size = 3, color ="black")+
            ggtitle(label = "15 hours - control for pops")
          tua.surv.15.pops
      #24 hours across all pops
          tua.surv.24 <- datum.surv |>
            filter(Hours == "24") |>
            ggplot(aes(x=Time_minutes, y=Surv)) + 
            geom_point(size=4)+
            geom_smooth(method=lm, se=TRUE)+
            scale_x_continuous(name="Time until plateau in minutes", breaks = seq(50, 225, by = 25), limits = c(50, 225))+
            scale_y_continuous(name="Number of surviving copepods", breaks = seq(0, 10, by = 1))+
            coord_cartesian(ylim = c(0,10))+
            scale_color_manual("Pop:",values=my_pal2)+
            theme(legend.position = "top", legend.direction = "horizontal", axis.title.y = element_text(size=11))+
            annotate("text", x = 75, y = 10, label =  bquote('p=0.301, R'^2*'=0.03'), size = 3, color ="black")+
            ggtitle(label = "24 hours - across all data")
          tua.surv.24
      #24 hours among pops
          tua.surv.24.pops <- datum.surv |>
            filter(Hours == "24") |>
            ggplot(aes(x=Time_minutes, y=Surv, col=Pop)) + 
            geom_point(size=4)+
            geom_smooth(method=lm, se=TRUE)+
            scale_x_continuous(name="Time until plateau in minutes", breaks = seq(50, 225, by = 25), limits = c(50, 225))+
            scale_y_continuous(name="", breaks = seq(0, 10, by = 1))+
            coord_cartesian(ylim = c(0,10))+
            scale_color_manual("Pop:",values=my_pal2)+
            theme(legend.position = "top", legend.direction = "horizontal", axis.title.y = element_text(size=11))+
            annotate("text", x = 75, y = 10, label =  bquote('p=0.196, R'^2*'=0.45'), size = 3, color ="black")+
            ggtitle(label = "24 hours - control for pops")
          tua.surv.24.pops

              
          ##Combine plots into one figure
          jpeg(filename = "Time to anoxia vs survival figure.jpg", width = 8, height = 12, units = "in", res = 300)
          ggarrange(tua.surv.6, tua.surv.6.pops, tua.surv.15, tua.surv.15.pops, tua.surv.24, tua.surv.24.pops,
                    nrow = 3,ncol = 2, labels = c("A", "B", "C", "D", "E", "F")
          ) 
          dev.off()
          
        
          
    
          
      
  