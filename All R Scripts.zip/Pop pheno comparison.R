#Comparison of resp statistics from populations
#Matthew Powers 
#powerm3@oregonstate.edu
#Statistics and figure creation
#Last edited 09-28-23

#load required packages
library(devtools)
library(MESS) #data wrangling and modeling
library(stats) #data wrangling and modeling
library(respirometry) #pcrit, alpha, nlr
library(ggpubr) #Also loads basic ggplot2
library(cowplot) #Pretty ggplots!
library(reshape2) #Data wrangling
library(dplyr) #Data wrangling
library(tidyverse) #Data wrangling
library(stringr) #data wrangling for splitting column characters
library(MetBrewer) #Pretty art colors!
library(MexBrewer) #Mexican art pretty colors!
library(palettetown) #Pokemon pretty colors!
library(runner) #Do functions on sliding windows of data
library(scales) #Preview color palettes
library(lme4) #statistical analysis
library(lmerTest) #Statistical analysis
library(agricolae) #data wrangling and modeling
library(emmeans) #statistical analysis
library(RColorBrewer) #plotting
library(car) #data wrangling and modeling
library(sf) #data wrangling and modeling
library(MuMIn) #For getting R squared values from mixed models
library(plotrix) #data wrangling and modeling
library(HH) #data wrangling and modeling
library(grid) #for adding tables to plots and making multiple panels
library(gridExtra) #for adding tables to plots and making multiple panels
library(glue) #Stick stuff in other stuff! Like pasting text in data frames and plot elements
library(patchwork) #stitching graphs together
library(ggiraph) #Connected interactive graphs
library(multcomp) #automatically assign pairwise significance groupings
library(multcompView) #See groupings from multcomp

#Set theme globally
theme_set(theme_cowplot())

#Read in data 
datum <- read.csv(file = "Pop resp statistics for R.csv", header = TRUE)

datum <- subset(datum, notes != "bubbles") #Remove wells with bubbles
datum <- subset(datum, notes != "crushed") #Remove wells with crushed individuals

datum <- subset(datum, Plateau == "yes") #Remove wells with no plateau

str(datum)  # check data coding

#Reassign data columns to proper coding (as factored categories)
datum$Date <- as.factor(datum$Date)
datum$Pop <- as.factor(datum$Pop)
datum$Mom.ID <- as.factor(datum$Mom.ID)
datum$Sex <- as.factor(datum$Sex)
datum$Plate <- as.factor(datum$Plate)
datum$Down <- as.factor(datum$Down)
datum$Surv <- as.factor(datum$Surv)

str(datum) #recheck data coding

#Relabel sex factor
datum %>% 
  mutate(Sex = fct_recode(Sex, "Female" = "F",
                          "Male" = "M")) -> datum

#Combine sex and population factors for plotting or stats groupings
datum$Pop.sex = paste(datum$Sex, datum$Pop)

#Combine Date and Plate factors for plotting or stats groupings
datum$Date.plate = paste(datum$Date, datum$Plate)

#Relevel factor
datum$Pop.sex <- factor(datum$Pop.sex, levels = c("Female SD", "Male SD","Female BR", "Male BR",
                                                  "Female BOB", "Male BOB", "Female SH", "Male SH")) 
table(datum$Pop.sex) #Check factor level order

datum$Pop <- factor(datum$Pop, levels = c("SD", "BR","BOB", "SH")) 

table(datum$Pop) #Check factor level order

table(datum$Pop.sex) #Check factor level order

#convert resp rates from mg O2 per hr to ug O2 per hour
datum$Upper_rate <- datum$Upper_rate*1000
datum$Lower_rate <- datum$Lower_rate*1000

datum$Upper_rate <- round(datum$Upper_rate, digits=4) #round upper rate, odd behavior with R keeping two extra digits?

##### Figure creation #####

#Color pallete tweaking for boxplots (optional)
br_pal <- met.brewer("Signac")
br_pal2 <- met.brewer("Renoir")
my_pal <- c(br_pal2[c(8,6)], br_pal[c(3,1)], br_pal2[c(2,4, 12,11)])
# just for displaying old and new palette - not required for solution
show_col(br_pal)
show_col(br_pal2)
show_col(my_pal)

#Color pallete tweaking for boxplots (optional)
br_pal <- met.brewer("Signac")
br_pal2 <- met.brewer("Renoir")
my_pal2 <- c(br_pal2[8], br_pal[3], br_pal2[c(2,12)])
# just for displaying old and new palette - not required for solution
show_col(br_pal)
show_col(br_pal2)
show_col(my_pal2)

#Color pallete tweaking for ggplot (optional)
br_pal3 <- pokepal(pokemon = "crawdaunt")
my_pal3 <- c(br_pal3[c(11,4)])
# just for displaying old and new palette - not required for solution
show_col(br_pal3)
show_col(my_pal3)


#Alpha statistic among populations

        #boxplot pop.sex
        Alphas.popsex <- ggplot(datum, aes(x=Pop.sex, y=Alpha, fill=Pop.sex))+
          geom_boxplot()+
          stat_summary(fun=mean, geom="point", shape=15, size=5, col="black")+
          geom_point()+
          scale_fill_manual("Groups:",values=my_pal)+
          theme(axis.title.x = element_blank())+
          theme(legend.position = "none", legend.direction = "horizontal", 
                axis.text.x = element_text(angle=45, hjust=1, vjust=1))+
          scale_y_continuous(name = expression(paste("Alpha ", P[Crit], " (", DO[2], " in mg/L ", O[2], ")")), breaks = seq(0,1.6, by =0.2), limits = c(-0.2,1.6))+
          annotate("text", 1, -0.2, label = "abc", size = 5)+
          annotate("text", 2, -0.2, label = "a", size = 5)+
          annotate("text", 3, -0.2, label = "c", size = 5)+
          annotate("text", 4, -0.2, label = "bc", size = 5)+
          annotate("text", 5, -0.2, label = "c", size = 5)+
          annotate("text", 6, -0.2, label = "c", size = 5)+
          annotate("text", 7, -0.2, label = "abc", size = 5)+
          annotate("text", 8, -0.2, label = "ab", size = 5)
        Alphas.popsex
        
        #boxplot pop
        Alphas.pop <- ggplot(datum, aes(x=Pop, y=Alpha, fill=Pop))+
          geom_boxplot()+
          stat_summary(fun=mean, geom="point", shape=15, size=5, col="black")+
          geom_point()+
          scale_fill_manual("Groups:",values=my_pal2)+
          theme(axis.title.x = element_blank())+
          theme(legend.position = "none", legend.direction = "horizontal")+
          scale_y_continuous(name = expression(paste("Alpha ", P[Crit], " (", DO[2], " in mg/L ", O[2], ")")), breaks = seq(0,1.6, by =0.2), limits = c(-0.2,1.6))+
          annotate("text", 1, -0.2, label = "a", size = 5)+
          annotate("text", 2, -0.2, label = "b", size = 5)+
          annotate("text", 3, -0.2, label = "b", size = 5)+
          annotate("text", 4, -0.2, label = "a", size = 5)
        Alphas.pop
        
        #boxplot sex
        Alphas.sex <- ggplot(datum, aes(x=Sex, y=Alpha, fill=Sex))+
          geom_boxplot()+
          stat_summary(fun=mean, geom="point", shape=15, size=5, col="black")+
          geom_point()+
          scale_fill_manual("Groups:",values=my_pal3)+
          theme(axis.title.x = element_blank())+
          theme(legend.position = "none", legend.direction = "horizontal")+
          scale_y_continuous(name = expression(paste("Alpha ", P[Crit], " (", DO[2], " in mg/L ", O[2], ")")), breaks = seq(0,1.6, by =0.2), limits = c(-0.2,1.6))+
          annotate("text", 1, -0.2, label = "a", size = 5)+
          annotate("text", 2, -0.2, label = "a", size = 5)
        Alphas.sex
        
        #Combine plots
        jpeg(file = "Alpha Combined.jpg", units = "in", width = 10, height = 5, res = 300)
        ggarrange(Alphas.sex, Alphas.pop, Alphas.popsex,
                  nrow = 1,ncol = 3,
                  labels = c("A", "B", "C"), label.x = 0, label.y = 1,
                  widths = c(1, 1, 1.5), heights = 1
        ) 
        dev.off()



#PCrit statistic among populations

          #Statistic summary
          datum.pcrit.mean <- datum |> 
            group_by(Pop) |> 
            summarise(mean = mean(Breakpoint) |> round(2),
                      n = n(),
                      iqr = IQR(Breakpoint),
                      range = paste(range(Breakpoint) |> round(2), collapse = ' - ')
            ) 
          
          write.csv(datum.pcrit.mean, file = "Mean Pcrit across pops.csv") #Save final frame as a csv
          
          #boxplot pop.sex
          PCrit.popsex <- ggplot(datum, aes(x=Pop.sex, y=Breakpoint, fill=Pop.sex))+
            geom_boxplot()+
            stat_summary(fun=mean, geom="point", shape=15, size=5, col="black")+
            geom_point()+
            scale_fill_manual("Groups:",values=my_pal)+
            theme(axis.title.x = element_blank())+
            theme(legend.position = "none", legend.direction = "horizontal", 
                  axis.text.x = element_text(angle=45, hjust=1, vjust=1))+
            scale_y_continuous(name = expression(paste(P[Crit], " (", DO[2], " in mg/L ", O[2], ")")), breaks = seq(0,6, by =1), limits = c(-0.3,6))+
            annotate("text", 1, -0.3, label = "a", size = 5)+
            annotate("text", 2, -0.3, label = "a", size = 5)+
            annotate("text", 3, -0.3, label = "ab", size = 5)+
            annotate("text", 4, -0.3, label = "b", size = 5)+
            annotate("text", 5, -0.3, label = "b", size = 5)+
            annotate("text", 6, -0.3, label = "b", size = 5)+
            annotate("text", 7, -0.3, label = "b", size = 5)+
            annotate("text", 8, -0.3, label = "b", size = 5)
          PCrit.popsex
          
          #boxplot pop
          PCrit.pop <- ggplot(datum, aes(x=Pop, y=Breakpoint, fill=Pop))+
            geom_boxplot()+
            stat_summary(fun=mean, geom="point", shape=15, size=5, col="black")+
            geom_point()+
            scale_fill_manual("Groups:",values=my_pal2)+
            theme(axis.title.x = element_blank())+
            theme(legend.position = "none", legend.direction = "horizontal")+
            scale_y_continuous(name = expression(paste(P[Crit], " (", DO[2], " in mg/L ", O[2], ")")), breaks = seq(0,6, by =1), limits = c(-0.3,6))+
            annotate("text", 1, -0.3, label = "a", size = 5)+
            annotate("text", 2, -0.3, label = "b", size = 5)+
            annotate("text", 3, -0.3, label = "b", size = 5)+
            annotate("text", 4, -0.3, label = "b", size = 5)
          PCrit.pop
          
          #boxplot sex
          PCrit.sex <- ggplot(datum, aes(x=Sex, y=Breakpoint, fill=Sex))+
            geom_boxplot()+
            stat_summary(fun=mean, geom="point", shape=15, size=5, col="black")+
            geom_point()+
            scale_fill_manual("Groups:",values=my_pal3)+
            theme(axis.title.x = element_blank())+
            theme(legend.position = "none", legend.direction = "horizontal")+
            scale_y_continuous(name = expression(paste(P[Crit], " (", DO[2], " in mg/L ", O[2], ")")), breaks = seq(0,6, by =1), limits = c(-0.3,6))+
            annotate("text", 1, -0.3, label = "a", size = 5)+
            annotate("text", 2, -0.3, label = "b", size = 5)
          PCrit.sex
          
          #Combine plots
          jpeg(file = "PCrit Combined.jpg", units = "in", width = 10, height = 5, res = 300)
          ggarrange(PCrit.sex, PCrit.pop, PCrit.popsex,
                    nrow = 1,ncol = 3,
                    labels = c("A", "B", "C"), label.x = 0, label.y = 1,
                    widths = c(1, 1, 1.5), heights = 1
          ) 
          dev.off()



#NLR PCrit statistic among populations

          #boxplot pop.sex
          NLR.popsex <- ggplot(subset(datum, NLR < 8), aes(x=Pop.sex, y=NLR, fill=Pop.sex))+
            geom_boxplot()+
            stat_summary(fun=mean, geom="point", shape=15, size=5, col="black")+
            geom_point()+
            scale_fill_manual("Groups:",values=my_pal)+
            theme(axis.title.x = element_blank())+
            theme(legend.position = "none", legend.direction = "horizontal", 
                  axis.text.x = element_text(angle=45, hjust=1, vjust=1))+
            scale_y_continuous(name = expression(paste("NLR ", P[Crit], " (", DO[2], " in mg/L ", O[2], ")")), breaks = seq(0,8, by =1), limits = c(-0.2,8))+
            annotate("text", 1, -0.2, label = "a", size = 5)+
            annotate("text", 2, -0.2, label = "a", size = 5)+
            annotate("text", 3, -0.2, label = "ac", size = 5)+
            annotate("text", 4, -0.2, label = "ab", size = 5)+
            annotate("text", 5, -0.2, label = "b", size = 5)+
            annotate("text", 6, -0.2, label = "ac", size = 5)+
            annotate("text", 7, -0.2, label = "d", size = 5)+
            annotate("text", 8, -0.2, label = "bc", size = 5)
          NLR.popsex
          
          #boxplot pop
          NLR.pop <- ggplot(subset(datum, NLR < 8), aes(x=Pop, y=NLR, fill=Pop))+
            geom_boxplot()+
            stat_summary(fun=mean, geom="point", shape=15, size=5, col="black")+
            geom_point()+
            scale_fill_manual("Groups:",values=my_pal2)+
            theme(axis.title.x = element_blank())+
            theme(legend.position = "none", legend.direction = "horizontal")+
            scale_y_continuous(name = expression(paste("NLR ", P[Crit], " (", DO[2], " in mg/L ", O[2], ")")), breaks = seq(0,8, by =1), limits = c(-0.2,8))+
            annotate("text", 1, -0.2, label = "a", size = 5)+
            annotate("text", 2, -0.2, label = "a", size = 5)+
            annotate("text", 3, -0.2, label = "b", size = 5)+
            annotate("text", 4, -0.2, label = "c", size = 5)
          NLR.pop
          
          #boxplot sex
          NLR.sex <- ggplot(subset(datum, NLR < 8), aes(x=Sex, y=NLR, fill=Sex))+
            geom_boxplot()+
            stat_summary(fun=mean, geom="point", shape=15, size=5, col="black")+
            geom_point()+
            scale_fill_manual("Groups:",values=my_pal3)+
            theme(axis.title.x = element_blank())+
            theme(legend.position = "none", legend.direction = "horizontal")+
            scale_y_continuous(name = expression(paste("NLR ", P[Crit], " (", DO[2], " in mg/L ", O[2], ")")), breaks = seq(0,8, by =1), limits = c(-0.2,8))+
            annotate("text", 1, -0.2, label = "a", size = 5)+
            annotate("text", 2, -0.2, label = "a", size = 5)
          NLR.sex
          
          #Combine plots
          jpeg(file = "NLR Combined.jpg", units = "in", width = 10, height = 5, res = 300)
          ggarrange(NLR.sex, NLR.pop, NLR.popsex,
                    nrow = 1,ncol = 3,
                    labels = c("A", "B", "C"), label.x = 0, label.y = 1,
                    widths = c(1, 1, 1.5), heights = 1
          ) 
          dev.off()



#RI statistic among populations

          #boxplot pop.sex
          RI.popsex <- ggplot(subset(datum, RI > -0.01), aes(x=Pop.sex, y=RI, fill=Pop.sex))+
            geom_boxplot()+
            stat_summary(fun=mean, geom="point", shape=15, size=5, col="black")+
            geom_point()+
            scale_fill_manual("Groups:",values=my_pal)+
            theme(axis.title.x = element_blank())+
            theme(legend.position = "none", legend.direction = "horizontal", 
                  axis.text.x = element_text(angle=45, hjust=1, vjust=1))+
            scale_y_continuous(name = expression(paste("Regulation Index")), breaks = seq(0,1, by =0.1), limits = c(0,1))+
            annotate("text", 1, 1, label = "a", size = 5)+
            annotate("text", 2, 1, label = "ab", size = 5)+
            annotate("text", 3, 1, label = "ab", size = 5)+
            annotate("text", 4, 1, label = "ab", size = 5)+
            annotate("text", 5, 1, label = "ab", size = 5)+
            annotate("text", 6, 1, label = "ab", size = 5)+
            annotate("text", 7, 1, label = "b", size = 5)+
            annotate("text", 8, 1, label = "ab", size = 5)
          RI.popsex
          
          #boxplot pop
          RI.pop <- ggplot(subset(datum, RI > -0.01), aes(x=Pop, y=RI, fill=Pop))+
            geom_boxplot()+
            stat_summary(fun=mean, geom="point", shape=15, size=5, col="black")+
            geom_point()+
            scale_y_continuous(name = expression(paste("Regulation Index")), breaks = seq(0,1, by =0.1), limits = c(0,1))+
            scale_fill_manual("Groups:",values=my_pal2)+
            theme(axis.title.x = element_blank())+
            theme(legend.position = "none", legend.direction = "horizontal")+
            ylab(expression(paste("RI (", DO[2], " in mg/L ", O[2], ")")))+
            annotate("text", 1, 1, label = "a", size = 5)+
            annotate("text", 2, 1, label = "a", size = 5)+
            annotate("text", 3, 1, label = "a", size = 5)+
            annotate("text", 4, 1, label = "a", size = 5)
          RI.pop
          
          #boxplot sex
          RI.sex <- ggplot(subset(datum, RI > -0.01), aes(x=Sex, y=RI, fill=Sex))+
            geom_boxplot()+
            stat_summary(fun=mean, geom="point", shape=15, size=5, col="black")+
            geom_point()+
            scale_y_continuous(name = expression(paste("Regulation Index")), breaks = seq(0,1, by =0.1), limits = c(0,1))+
            scale_fill_manual("Groups:",values=my_pal3)+
            theme(axis.title.x = element_blank())+
            theme(legend.position = "none", legend.direction = "horizontal")+
            ylab(expression(paste("RI (", DO[2], " in mg/L ", O[2], ")")))+
            annotate("text", 1, 0, label = "a", size = 5)+
            annotate("text", 2, 0, label = "a", size = 5)
          RI.sex
          
          #Combine plots
          jpeg(file = "RI Combined.jpg", units = "in", width = 10, height = 5, res = 300)
          ggarrange(RI.sex, RI.pop, RI.popsex,
                    nrow = 1,ncol = 3,
                    labels = c("A", "B", "C"), label.x = 0, label.y = 1,
                    widths = c(1, 1, 1.5), heights = c(1)
          ) 
          dev.off()
      
      
#Upper Resp Rate  among populations
      greek <- paste("\U03B1","\U03B2","\U03B5","\U03BC","\U03C0","\U03A8")
      greek
      
      #boxplot pop.sex
      Upper_rate.popsex <- ggplot(datum, aes(x=Pop.sex, y=Upper_rate, fill=Pop.sex))+
        geom_boxplot()+
        stat_summary(fun=mean, geom="point", shape=15, size=5, col="black")+
        geom_point()+
        scale_fill_manual("Groups:",values=my_pal)+
        theme(axis.title.x = element_blank())+
        theme(legend.position = "none", legend.direction = "horizontal", 
              axis.text.x = element_text(angle=45, hjust=1, vjust=1), axis.title.y = element_text(size=12))+
        scale_y_continuous(name = expression(paste("Normoxic Metabolic Rate (", " in μg ", O[2], " ", mm^-1, " per hr)")), 
                           breaks = seq(0,0.06, by =0.01), limits = c(0,0.06))+
        annotate("text", 1, 0, label = "a", size = 5)+
        annotate("text", 2, 0, label = "a", size = 5)+
        annotate("text", 3, 0, label = "a", size = 5)+
        annotate("text", 4, 0, label = "a", size = 5)+
        annotate("text", 5, 0, label = "a", size = 5)+
        annotate("text", 6, 0, label = "a", size = 5)+
        annotate("text", 7, 0, label = "a", size = 5)+
        annotate("text", 8, 0, label = "a", size = 5)
      Upper_rate.popsex
      
      #boxplot pop
      Upper_rate.pop <- ggplot(datum, aes(x=Pop, y=Upper_rate, fill=Pop))+
        geom_boxplot()+
        stat_summary(fun=mean, geom="point", shape=15, size=5, col="black")+
        geom_point()+
        scale_fill_manual("Groups:",values=my_pal2)+
        theme(axis.title.x = element_blank())+
        theme(legend.position = "none", legend.direction = "horizontal", axis.title.y = element_text(size=12))+
        scale_y_continuous(name = expression(paste("Normoxic Metabolic Rate (", " in μg ", O[2], " ", mm^-1, " per hr)")), 
                           breaks = seq(0,0.06, by =0.01), limits = c(0,0.06))+
        annotate("text", 1, 0.005, label = "a", size = 5)+
        annotate("text", 2, 0.005, label = "a", size = 5)+
        annotate("text", 3, 0.005, label = "a", size = 5)+
        annotate("text", 4, 0.005, label = "a", size = 5)
      Upper_rate.pop
      
      #boxplot sex
      Upper_rate.sex <- ggplot(datum, aes(x=Sex, y=Upper_rate, fill=Sex))+
        geom_boxplot()+
        stat_summary(fun=mean, geom="point", shape=15, size=5, col="black")+
        geom_point()+
        scale_fill_manual("Groups:",values=my_pal3)+
        theme(axis.title.x = element_blank())+
        theme(legend.position = "none", legend.direction = "horizontal", axis.title.y = element_text(size=12))+
        scale_y_continuous(name = expression(paste("Normoxic Metabolic Rate (", " in μg ", O[2], " ", mm^-1, " per hr)")), 
                           breaks = seq(0,0.06, by =0.01), limits = c(0,0.06))+
        annotate("text", 1, 0.005, label = "a", size = 5)+
        annotate("text", 2, 0.005, label = "a", size = 5)
      Upper_rate.sex
      
      #Combine plots
      jpeg(file = "Upper_rate Combined.jpg", units = "in", width = 10, height = 5, res = 300)
      ggarrange(Upper_rate.sex, Upper_rate.pop, Upper_rate.popsex,
                nrow = 1,ncol = 3,
                labels = c("A", "B", "C"), label.x = 0, label.y = 1,
                widths = c(1, 1, 1.5), heights = c(1)
      ) 
      dev.off()
      
      
      
#Lower Resp rate among populations
      
      #boxplot pop.sex
      Lower_rate.popsex <- ggplot(datum, aes(x=Pop.sex, y=Lower_rate, fill=Pop.sex))+
        geom_boxplot()+
        stat_summary(fun=mean, geom="point", shape=15, size=5, col="black")+
        geom_point()+
        scale_fill_manual("Groups:",values=my_pal)+
        theme(axis.title.x = element_blank())+
        theme(legend.position = "none", legend.direction = "horizontal", 
              axis.text.x = element_text(angle=45, hjust=1, vjust=1), axis.title.y = element_text(size=12))+
        scale_y_continuous(name = expression(paste("Hypoxic Metabolic Rate (", " in μg ", O[2], " ", mm^-1, " per hr)")), 
                           breaks = seq(0,0.06, by =0.01), limits = c(0,0.06))+
        annotate("text", 1, 0, label = "ab", size = 5)+
        annotate("text", 2, 0, label = "a", size = 5)+
        annotate("text", 3, 0, label = "ab", size = 5)+
        annotate("text", 4, 0, label = "b", size = 5)+
        annotate("text", 5, 0, label = "b", size = 5)+
        annotate("text", 6, 0, label = "ab", size = 5)+
        annotate("text", 7, 0, label = "b", size = 5)+
        annotate("text", 8, 0, label = "ab", size = 5)
      Lower_rate.popsex
      
      #boxplot pop
      Lower_rate.pop <- ggplot(datum, aes(x=Pop, y=Lower_rate, fill=Pop))+
        geom_boxplot()+
        stat_summary(fun=mean, geom="point", shape=15, size=5, col="black")+
        geom_point()+
        scale_fill_manual("Groups:",values=my_pal2)+
        theme(axis.title.x = element_blank())+
        theme(legend.position = "none", legend.direction = "horizontal", axis.title.y = element_text(size=12))+
        scale_y_continuous(name = expression(paste("Hypoxic Metabolic Rate (", " in μg ", O[2], " ", mm^-1, " per hr)")), 
                           breaks = seq(0,0.06, by =0.01), limits = c(0,0.06))+
        annotate("text", 1,0, label = "a", size = 5)+
        annotate("text", 2, 0, label = "b", size = 5)+
        annotate("text", 3, 0, label = "b", size = 5)+
        annotate("text", 4, 0, label = "b", size = 5)
      Lower_rate.pop
      
      #boxplot sex
      Lower_rate.sex <- ggplot(datum, aes(x=Sex, y=Lower_rate, fill=Sex))+
        geom_boxplot()+
        stat_summary(fun=mean, geom="point", shape=15, size=5, col="black")+
        geom_point()+
        scale_fill_manual("Groups:",values=my_pal3)+
        theme(axis.title.x = element_blank())+
        theme(legend.position = "none", legend.direction = "horizontal", axis.title.y = element_text(size=12))+
        scale_y_continuous(name = expression(paste("Hypoxic Metabolic Rate (", " in μg ", O[2], " ", mm^-1, " per hr)")), 
                           breaks = seq(0,0.06, by =0.01), limits = c(0,0.06))+
        annotate("text", 1, 0, label = "a", size = 5)+
        annotate("text", 2, 0, label = "a", size = 5)
      Lower_rate.sex
      
      #Combine plots
      jpeg(file = "Lower_rate Combined.jpg", units = "in", width = 10, height = 5, res = 300)
      ggarrange(Lower_rate.sex, Lower_rate.pop, Lower_rate.popsex,
                nrow = 1,ncol = 3,
                labels = c("A", "B", "C"), label.x = 0, label.y = 1,
                widths = c(1, 1, 1.5), heights = c(1)
      ) 
      dev.off()
      
      
      
      
#Body lengths among pops and sexes
      
      #boxplot pop.sex
      length.popsex <- ggplot(datum[-c(9),], aes(x=Pop.sex, y=Totlen, fill=Pop.sex))+
        geom_boxplot()+
        stat_summary(fun=mean, geom="point", shape=15, size=5, col="black")+
        geom_point()+
        scale_y_continuous(breaks = seq(1,2.5, by =0.2), limits = c(1,2.5)) +
        scale_fill_manual("Groups:",values=my_pal)+
        theme(axis.title.x = element_blank())+
        theme(legend.position = "none", legend.direction = "horizontal", 
              axis.text.x = element_text(angle=45, hjust=1, vjust=1), axis.title.y = element_text(size=12))+
        ylab(expression(paste("Body Length (mm)")))+
        annotate("text", 1, 1, label = "ab", size = 5)+
        annotate("text", 2, 1, label = "a", size = 5)+
        annotate("text", 3, 1, label = "c", size = 5)+
        annotate("text", 4, 1, label = "bc", size = 5)+
        annotate("text", 5, 1, label = "c", size = 5)+
        annotate("text", 6, 1, label = "c", size = 5)+
        annotate("text", 7, 1, label = "d", size = 5)+
        annotate("text", 8, 1, label = "d", size = 5)
      length.popsex
      
      #boxplot pop
      length.pop <- ggplot(datum[-c(9),], aes(x=Pop, y=Totlen, fill=Pop))+
        geom_boxplot()+
        stat_summary(fun=mean, geom="point", shape=15, size=5, col="black")+
        geom_point()+
        scale_y_continuous(breaks = seq(1,2.5, by =0.2), limits = c(1,2.5)) +
        scale_fill_manual("Groups:",values=my_pal2)+
        theme(axis.title.x = element_blank())+
        theme(legend.position = "none", legend.direction = "horizontal", axis.title.y = element_text(size=12))+
        ylab(expression(paste("Body Length (mm)")))+
        annotate("text", 1,1, label = "a", size = 5)+
        annotate("text", 2, 1, label = "b", size = 5)+
        annotate("text", 3, 1, label = "b", size = 5)+
        annotate("text", 4, 1, label = "c", size = 5)
      length.pop
      
      #boxplot sex
      length.sex <- ggplot(datum[-c(9),], aes(x=Sex, y=Totlen, fill=Sex))+
        geom_boxplot()+
        stat_summary(fun=mean, geom="point", shape=15, size=5, col="black")+
        geom_point()+
        scale_y_continuous(breaks = seq(1,2.5, by =0.2), limits = c(1,2.5)) +
        scale_fill_manual("Groups:",values=my_pal3)+
        theme(axis.title.x = element_blank())+
        theme(legend.position = "none", legend.direction = "horizontal", axis.title.y = element_text(size=12))+
        ylab(expression(paste("Body Length (mm)")))+
        annotate("text", 1, 1, label = "a", size = 5)+
        annotate("text", 2, 1, label = "b", size = 5)
      length.sex
      
      #Combine plots
      jpeg(file = "Length Combined.jpg", units = "in", width = 10, height = 5, res = 300)
      ggarrange(length.sex, length.pop, length.popsex,
                nrow = 1,ncol = 3,
                labels = c("A", "B", "C"), label.x = 0, label.y = 1,
                widths = c(1, 1, 1.5), heights = c(1)
      ) 
      dev.off()
      
      
#### Combine pop, sex, and pop.sex plots into separate figures for alpha, pcrit, nlr, and RI
      
      #Pop
      jpeg(file = "Pop resp statistics.jpg", units = "in", width = 9, height = 8, res = 300)
      ggarrange(PCrit.pop, NLR.pop, Alphas.pop, RI.pop,
                nrow = 2,ncol = 2,
                labels = c("A", "B", "C", "D")
      ) 
      dev.off()
      
      
      #Sex
      jpeg(file = "Sex resp statistics.jpg", units = "in", width = 9, height = 8, res = 300)
      ggarrange(PCrit.sex, NLR.sex, Alphas.sex, RI.sex,
                nrow = 2,ncol = 2,
                labels = c("A", "B", "C", "D")
      ) 
      dev.off()
      
      
      #Pop.sex
      jpeg(file = "Popsex resp statistics.jpg", units = "in", width = 9, height = 8, res = 300)
      ggarrange(PCrit.popsex, NLR.popsex, Alphas.popsex, RI.popsex,
                nrow = 2,ncol = 2,
                labels = c("A", "B", "C", "D")
      ) 
      dev.off()
      
      
#### Combine pop, sex, and pop.sex plots into separate figures for respiratory rates
      
      #Pop
      jpeg(file = "Pop resp rates.jpg", units = "in", width = 9, height = 6, res = 300)
      ggarrange(Upper_rate.pop, Lower_rate.pop,
                nrow = 1,ncol = 2,
                labels = c("A", "B")
      ) 
      dev.off()
      
      
      #Sex
      jpeg(file = "Sex resp rates.jpg", units = "in", width = 9, height = 6, res = 300)
      ggarrange(Upper_rate.sex, Lower_rate.sex,
                nrow = 1,ncol = 2,
                labels = c("A", "B")
      ) 
      dev.off()
      
      
      #Pop.sex
      jpeg(file = "Popsex resp rates.jpg", units = "in", width = 9, height = 6, res = 300)
      ggarrange(Upper_rate.popsex, Lower_rate.popsex, 
                nrow = 1,ncol = 2,
                labels = c("A", "B")
      ) 
      dev.off()
  
  
      

      
##### Statistical analysis ######

#####Is there a difference in each plate resp statistic among populations?
      
  #Alpha
      mod.alpha.popsex <- lm(Alpha ~ Pop.sex, data = datum)
      mod.alpha.pop <- lmer(Alpha ~ Pop + (1|Sex), data = datum)
      mod.alpha.sex <- lmer(Alpha ~ Sex + (1|Pop), data = datum)
      cld(emmeans(mod.alpha.popsex, pairwise ~ Pop.sex)) #Get CLDs 
      cld(emmeans(mod.alpha.pop, pairwise ~ Pop)) #Get CLDs
      cld(emmeans(mod.alpha.sex, pairwise ~ Sex)) #Get CLDs
      #Export data
      comp.1 <- emmeans(mod.alpha.popsex, pairwise ~ Pop.sex)
      write.csv(comp.1$emmeans, file = "alphas by popsex emmeans.csv", row.names = FALSE)
      write.csv(comp.1$contrasts, file = "alphas by popsex contrasts.csv", row.names = FALSE)
      write.csv(confint(comp.1$contrasts), file = "alphas by popsex contrasts CIs.csv", row.names = FALSE)
      
      comp.1b <- emmeans(mod.alpha.pop, pairwise ~ Pop)
      write.csv(comp.1b$emmeans, file = "alphas by pop emmeans.csv", row.names = FALSE)
      write.csv(comp.1b$contrasts, file = "alphas by pop contrasts.csv", row.names = FALSE)
      write.csv(confint(comp.1b$contrasts), file = "alphas by pop contrasts CIs.csv", row.names = FALSE)
      
      comp.1c <- emmeans(mod.alpha.sex, pairwise ~ Sex)
      write.csv(comp.1c$emmeans, file = "alphas by sex emmeans.csv", row.names = FALSE)
      write.csv(comp.1c$contrasts, file = "alphas by sex contrasts.csv", row.names = FALSE)
      write.csv(confint(comp.1c$contrasts), file = "alphas by sex contrasts CIs.csv", row.names = FALSE)
      
  #PCrit
      mod.Pcrit.popsex <- lm(Breakpoint ~ Pop.sex, data = datum)
      mod.Pcrit.pop <- lmer(Breakpoint ~ Pop + (1|Sex), data = datum)
      mod.Pcrit.sex <- lmer(Breakpoint ~ Sex + (1|Pop), data = datum)
      cld(emmeans(mod.Pcrit.popsex, pairwise ~ Pop.sex)) #Get CLDs
          cld(emmeans(mod.Pcrit.pop, pairwise ~ Pop)) #Get CLDs
              cld(emmeans(mod.Pcrit.sex, pairwise ~ Sex)) #Get CLDs
      #Export data
      comp.2 <- emmeans(mod.Pcrit.popsex, pairwise ~ Pop.sex)
      write.csv(comp.2$emmeans, file = "Pcrit by popsex emmeans.csv", row.names = FALSE)
      write.csv(comp.2$contrasts, file = "Pcrit by popsex contrasts.csv", row.names = FALSE)
      write.csv(confint(comp.2$contrasts), file = "Pcrit by popsex contrasts CIs.csv", row.names = FALSE)
      
      comp.2b <- emmeans(mod.Pcrit.pop, pairwise ~ Pop)
      write.csv(comp.2b$emmeans, file = "Pcrit by pop emmeans.csv", row.names = FALSE)
      write.csv(comp.2b$contrasts, file = "Pcrit by pop contrasts.csv", row.names = FALSE)
      write.csv(confint(comp.2b$contrasts), file = "Pcrit by pop contrasts CIs.csv", row.names = FALSE)
      
      comp.2c <- emmeans(mod.Pcrit.sex, pairwise ~ Sex)
      write.csv(comp.2c$emmeans, file = "Pcrit by sex emmeans.csv", row.names = FALSE)
      write.csv(comp.2c$contrasts, file = "Pcrit by sex contrasts.csv", row.names = FALSE)
      write.csv(confint(comp.2c$contrasts), file = "Pcrit by sex contrasts CIs.csv", row.names = FALSE)
      
  #NLR
      mod.NLR.popsex <- lm(NLR ~ Pop.sex, data = subset(datum, NLR < 8))
      mod.NLR.pop <- lmer(NLR ~ Pop + (1|Sex), data = subset(datum, NLR < 8))
      mod.NLR.sex <- lmer(NLR ~ Sex + (1|Pop), data = subset(datum, NLR < 8))
      cld(emmeans(mod.NLR.popsex, pairwise ~ Pop.sex)) #Get CLDs
          cld(emmeans(mod.NLR.pop, pairwise ~ Pop)) #Get CLDs
              cld(emmeans(mod.NLR.sex, pairwise ~ Sex)) #Get CLDs
      #Export data
      comp.3 <- emmeans(mod.NLR.popsex, pairwise ~ Pop.sex)
      write.csv(comp.3$emmeans, file = "NLR by popsex emmeans.csv", row.names = FALSE)
      write.csv(comp.3$contrasts, file = "NLR by popsex contrasts.csv", row.names = FALSE)
      write.csv(confint(comp.3$contrasts), file = "NLR by popsex contrasts CIs.csv", row.names = FALSE)
      
      comp.3b <- emmeans(mod.NLR.pop, pairwise ~ Pop)
      write.csv(comp.3b$emmeans, file = "NLR by pop emmeans.csv", row.names = FALSE)
      write.csv(comp.3b$contrasts, file = "NLR by pop contrasts.csv", row.names = FALSE)
      write.csv(confint(comp.3b$contrasts), file = "NLR by pop contrasts CIs.csv", row.names = FALSE)
      
      comp.3c <- emmeans(mod.NLR.sex, pairwise ~ Sex)
      write.csv(comp.3c$emmeans, file = "NLR by sex emmeans.csv", row.names = FALSE)
      write.csv(comp.3c$contrasts, file = "NLR by sex contrasts.csv", row.names = FALSE)
      write.csv(confint(comp.3c$contrasts), file = "NLR by sex contrasts CIs.csv", row.names = FALSE)
      
  #RI
      mod.RI.popsex <- lm(RI ~ Pop.sex, data = datum)
      mod.RI.pop <- lmer(RI ~ Pop + (1|Sex), data = datum)
      mod.RI.sex <- lmer(RI ~ Sex + (1|Pop), data = datum)
      cld(emmeans(mod.RI.popsex, pairwise ~ Pop.sex)) #Get CLDs
          cld(emmeans(mod.RI.pop, pairwise ~ Pop)) #Get CLDs
              cld(emmeans(mod.RI.sex, pairwise ~ Sex)) #Get CLDs
      #Export data
      comp.4 <- emmeans(mod.RI.popsex, pairwise ~ Pop.sex)
      write.csv(comp.4$emmeans, file = "RI by popsex emmeans.csv", row.names = FALSE)
      write.csv(comp.4$contrasts, file = "RI by popsex contrasts.csv", row.names = FALSE)
      write.csv(confint(comp.4$contrasts), file = "RI by popsex contrasts CIs.csv", row.names = FALSE)
      
      comp.4b <- emmeans(mod.RI.pop, pairwise ~ Pop)
      write.csv(comp.4b$emmeans, file = "RI by pop emmeans.csv", row.names = FALSE)
      write.csv(comp.4b$contrasts, file = "RI by pop contrasts.csv", row.names = FALSE)
      write.csv(confint(comp.4b$contrasts), file = "RI by pop contrasts CIs.csv", row.names = FALSE)
      
      comp.4c <- emmeans(mod.RI.sex, pairwise ~ Sex)
      write.csv(comp.4c$emmeans, file = "RI by sex emmeans.csv", row.names = FALSE)
      write.csv(comp.4c$contrasts, file = "RI by sex contrasts.csv", row.names = FALSE)
      write.csv(confint(comp.4c$contrasts), file = "RI by sex contrasts CIs.csv", row.names = FALSE)
      
  #Upper resp rate
      mod.Upper_rate.popsex <- lm(Upper_rate ~ Pop.sex, data = datum)
      mod.Upper_rate.pop <- lmer(Upper_rate ~ Pop +  (1|Sex), data = datum)
      mod.Upper_rate.sex <- lmer(Upper_rate ~ Sex + (1|Pop), data = datum)
      cld(emmeans(mod.Upper_rate.popsex, pairwise ~ Pop.sex)) #Get CLDs
          cld(emmeans(mod.Upper_rate.pop, pairwise ~ Pop)) #Get CLDs
              cld(emmeans(mod.Upper_rate.sex, pairwise ~ Sex)) #Get CLDs
      #Export data
      comp.5 <- emmeans(mod.Upper_rate.popsex, pairwise ~ Pop.sex)
      write.csv(comp.5$emmeans, file = "Upper by popsex emmeans.csv", row.names = FALSE)
      write.csv(comp.5$contrasts, file = "Upper by popsex contrasts.csv", row.names = FALSE)
      write.csv(confint(comp.5$contrasts), file = "Upper by popsex contrasts CIs.csv", row.names = FALSE)
      
      comp.5b <- emmeans(mod.Upper_rate.pop, pairwise ~ Pop)
      write.csv(comp.5b$emmeans, file = "Upper by pop emmeans.csv", row.names = FALSE)
      write.csv(comp.5b$contrasts, file = "Upper by pop contrasts.csv", row.names = FALSE)
      write.csv(confint(comp.5b$contrasts), file = "Upper by pop contrasts CIs.csv", row.names = FALSE)
      
      comp.5c <- emmeans(mod.Upper_rate.sex, pairwise ~ Sex)
      write.csv(comp.5c$emmeans, file = "Upper by sex emmeans.csv", row.names = FALSE)
      write.csv(comp.5c$contrasts, file = "Upper by sex contrasts.csv", row.names = FALSE)
      write.csv(confint(comp.5c$contrasts), file = "Upper by sex contrasts CIs.csv", row.names = FALSE)
      
  #Lower resp rate
      mod.Lower_rate.popsex <- lm(Lower_rate ~ Pop.sex, data = datum)
      mod.Lower_rate.pop <- lmer(Lower_rate ~ Pop +  (1|Sex), data = datum)
      mod.Lower_rate.sex <- lmer(Lower_rate ~ Sex +  (1|Pop), data = datum)
      cld(emmeans(mod.Lower_rate.popsex, pairwise ~ Pop.sex)) #Get CLDs
          cld(emmeans(mod.Lower_rate.pop, pairwise ~ Pop)) #Get CLDs
              cld(emmeans(mod.Lower_rate.sex, pairwise ~ Sex)) #Get CLDs
      #Export data
      comp.6 <- emmeans(mod.Lower_rate.popsex, pairwise ~ Pop.sex)
      write.csv(comp.6$emmeans, file = "Lower by popsex emmeans.csv", row.names = FALSE)
      write.csv(comp.6$contrasts, file = "Lower by popsex contrasts.csv", row.names = FALSE)
      write.csv(confint(comp.6$contrasts), file = "Lower by popsex contrasts CIs.csv", row.names = FALSE)
      
      comp.6b <- emmeans(mod.Lower_rate.pop, pairwise ~ Pop)
      write.csv(comp.6b$emmeans, file = "Lower by pop emmeans.csv", row.names = FALSE)
      write.csv(comp.6b$contrasts, file = "Lower by pop contrasts.csv", row.names = FALSE)
      write.csv(confint(comp.6b$contrasts), file = "Lower by pop contrasts CIs.csv", row.names = FALSE)
      
      comp.6c <- emmeans(mod.Lower_rate.sex, pairwise ~ Sex)
      write.csv(comp.6c$emmeans, file = "Lower by sex emmeans.csv", row.names = FALSE)
      write.csv(comp.6c$contrasts, file = "Lower by sex contrasts.csv", row.names = FALSE)
      write.csv(confint(comp.6c$contrasts), file = "Lower by sex contrasts CIs.csv", row.names = FALSE)
      
  #Body length (remove one row with one copepod)
      mod.length.popsex <- lm(Totlen ~ Pop.sex, data = datum[-c(9),])
      mod.length.pop <- lmer(Totlen ~ Pop +  (1|Sex), data = datum[-c(9),])
      mod.length.sex <- lmer(Totlen ~ Sex +  (1|Pop), data = datum[-c(9),])
      cld(emmeans(mod.length.popsex, pairwise ~ Pop.sex)) #Get CLDs
          cld( emmeans(mod.length.pop, pairwise ~ Pop)) #Get CLDs
               cld(emmeans(mod.length.sex, pairwise ~ Sex)) #Get CLDs
      #Export data
      comp.7 <- emmeans(mod.length.popsex, pairwise ~ Pop.sex)
      write.csv(comp.7$emmeans, file = "length by popsex emmeans.csv", row.names = FALSE)
      write.csv(comp.7$contrasts, file = "length by popsex contrasts.csv", row.names = FALSE)
      write.csv(confint(comp.7$contrasts), file = "length by popsex contrasts CIs.csv", row.names = FALSE)
      
      comp.7b <- emmeans(mod.length.pop, pairwise ~ Pop)
      write.csv(comp.7b$emmeans, file = "length by pop emmeans.csv", row.names = FALSE)
      write.csv(comp.7b$contrasts, file = "length by pop contrasts.csv", row.names = FALSE)
      write.csv(confint(comp.7b$contrasts), file = "length by pop contrasts CIs.csv", row.names = FALSE)
      
      comp.7c <- emmeans(mod.length.sex, pairwise ~ Sex)
      write.csv(comp.7c$emmeans, file = "length by sex emmeans.csv", row.names = FALSE)
      write.csv(comp.7c$contrasts, file = "length by sex contrasts.csv", row.names = FALSE)
      write.csv(confint(comp.7c$contrasts), file = "length by sex contrasts CIs.csv", row.names = FALSE)
      
      
#### Stat summary across all populations ####
      
      datum.total.summary <- datum |> 
        filter(NLR < 8) |>
        summarise(n = n(),
                  mean.alpha = mean(Alpha, na.rm=TRUE) |> round(4), #Alpha
                  iqr.alpha = IQR(Alpha, na.rm=TRUE),
                  range.alpha = paste(range(Alpha, na.rm=TRUE) |> round(4), collapse = ' - '),
                  mean.pcrit = mean(Breakpoint, na.rm=TRUE) |> round(4), #Pcrit
                  iqr.pcrit = IQR(Breakpoint, na.rm=TRUE),
                  range.pcrit = paste(range(Breakpoint, na.rm=TRUE) |> round(4), collapse = ' - '),
                  mean.NLR = mean(NLR, na.rm=TRUE) |> round(4), #NLR
                  iqr.NLR = IQR(NLR, na.rm=TRUE),
                  range.NLR = paste(range(NLR, na.rm=TRUE) |> round(4), collapse = ' - '),
                  mean.RI = mean(RI, na.rm=TRUE) |> round(4), #RI
                  iqr.RI = IQR(RI, na.rm=TRUE),
                  range.RI = paste(range(RI, na.rm=TRUE) |> round(4), collapse = ' - '),
                  mean.Upper = mean(Upper_rate, na.rm=TRUE) |> round(4), #Upper rate
                  iqr.Upper = IQR(Upper_rate, na.rm=TRUE),
                  range.Upper = paste(range(Upper_rate, na.rm=TRUE) |> round(4), collapse = ' - '),
                  mean.Lower = mean(Lower_rate, na.rm=TRUE) |> round(4), #Lower rate
                  iqr.Lower = IQR(Lower_rate, na.rm=TRUE),
                  range.Lower = paste(range(Lower_rate, na.rm=TRUE) |> round(4), collapse = ' - ')
        ) 
      
      datum.total.summary2 <- data.frame(t(datum.total.summary))
      colnames(datum.total.summary2) <- "Summary value"
      
      write.csv(datum.total.summary2, file = "Mean statistics across all populations.csv") #Save final frame as a csv
      
      
  #### Resp statistics regression plots (extra) ####
      
      #All variables square root transformed to conform to assumptions of normality using log transformation 
        
      
    #Alpha vs others
      plot.7 <- datum |>
        filter(NLR < 8) |>
        ggplot(aes(x=sqrt(Alpha), y=sqrt(Breakpoint), col=Pop))+
        geom_point( pch=16, size=5)+
        geom_line(stat='smooth', method = "lm",linewidth = 1)+
        geom_ribbon(aes(col = NULL, group = Pop), stat='smooth', method = "lm", se=TRUE, alpha=0.1)+
        scale_color_manual("Treatment:", values=my_pal2)+
        theme(axis.text.x = element_text(size = 11),
              axis.title = element_text(size = 13),
              axis.text.y = element_text(size=10),
              legend.position = "none", legend.direction = "vertical")
      plot.7
      
      
      plot.7b <- datum |>
        filter(NLR < 8) |>
        ggplot(aes(x=sqrt(Alpha), y=sqrt(NLR), col=Pop))+
        geom_point( pch=16, size=5)+
        geom_line(stat='smooth', method = "lm",linewidth = 1)+
        geom_ribbon(aes(col = NULL, group = Pop), stat='smooth', method = "lm", se=TRUE, alpha=0.1)+
        scale_color_manual("Treatment:", values=my_pal2)+
        theme(axis.text.x = element_text(size = 11),
              axis.title = element_text(size = 13),
              axis.text.y = element_text(size=10),
              legend.position = "none", legend.direction = "vertical")
      plot.7b
      
      plot.7c <- datum |>
        filter(NLR < 8) |>
        ggplot(aes(x=sqrt(Alpha), y=sqrt(RI), col=Pop))+
        geom_point( pch=16, size=5)+
        geom_line(stat='smooth', method = "lm",linewidth = 1)+
        geom_ribbon(aes(col = NULL, group = Pop), stat='smooth', method = "lm", se=TRUE, alpha=0.1)+
        scale_color_manual("Treatment:", values=my_pal2)+
        theme(axis.text.x = element_text(size = 11),
              axis.title = element_text(size = 13),
              axis.text.y = element_text(size=10),
              legend.position = "none", legend.direction = "horizontal")
      plot.7c
      
      plot.7d <- datum |>
        filter(NLR < 8) |>
        ggplot(aes(x=sqrt(Alpha), y=sqrt(Upper_rate), col=Pop))+
        geom_point( pch=16, size=5)+
        geom_line(stat='smooth', method = "lm",linewidth = 1)+
        geom_ribbon(aes(col = NULL, group = Pop), stat='smooth', method = "lm", se=TRUE, alpha=0.1)+
        scale_color_manual("Treatment:", values=my_pal2)+
        theme(axis.text.x = element_text(size = 11),
              axis.title = element_text(size = 13),
              axis.text.y = element_text(size=10),
              legend.position = "none", legend.direction = "vertical")
      plot.7d
      
      plot.7e <- datum |>
        filter(NLR < 8) |>
        ggplot(aes(x=sqrt(Alpha), y=sqrt(Lower_rate), col=Pop))+
        geom_point( pch=16, size=5)+
        geom_line(stat='smooth', method = "lm",linewidth = 1)+
        geom_ribbon(aes(col = NULL, group = Pop), stat='smooth', method = "lm", se=TRUE, alpha=0.1)+
        scale_color_manual("Treatment:", values=my_pal2)+
        theme(axis.text.x = element_text(size = 11),
              axis.title = element_text(size = 13),
              axis.text.y = element_text(size=10),
              legend.position = "none", legend.direction = "vertical")
      plot.7e

      
    #Pcrit vs others
      plot.7f <- datum |>
        filter(NLR < 8) |>
        ggplot(aes(x=sqrt(Breakpoint), y=sqrt(NLR), col=Pop))+
        geom_point( pch=16, size=5)+
        geom_line(stat='smooth', method = "lm",linewidth = 1)+
        geom_ribbon(aes(col = NULL, group = Pop), stat='smooth', method = "lm", se=TRUE, alpha=0.1)+
        scale_color_manual("Treatment:", values=my_pal2)+
        theme(axis.text.x = element_text(size = 11),
              axis.title = element_text(size = 13),
              axis.text.y = element_text(size=10),
              legend.position = "none", legend.direction = "vertical")
      plot.7f
      
      plot.7g <- datum |>
        filter(NLR < 8) |>
        ggplot(aes(x=sqrt(Breakpoint), y=sqrt(RI), col=Pop))+
        geom_point( pch=16, size=5)+
        geom_line(stat='smooth', method = "lm",linewidth = 1)+
        geom_ribbon(aes(col = NULL, group = Pop), stat='smooth', method = "lm", se=TRUE, alpha=0.1)+
        scale_color_manual("Treatment:", values=my_pal2)+
        theme(axis.text.x = element_text(size = 11),
              axis.title = element_text(size = 13),
              axis.text.y = element_text(size=10),
              legend.position = "none", legend.direction = "vertical")
      plot.7g
      
      plot.7h <- datum |>
        filter(NLR < 8) |>
        ggplot(aes(x=sqrt(Breakpoint), y=sqrt(Upper_rate), col=Pop))+
        geom_point( pch=16, size=5)+
        geom_line(stat='smooth', method = "lm",linewidth = 1)+
        geom_ribbon(aes(col = NULL, group = Pop), stat='smooth', method = "lm", se=TRUE, alpha=0.1)+
        scale_color_manual("Treatment:", values=my_pal2)+
        theme(axis.text.x = element_text(size = 11),
              axis.title = element_text(size = 13),
              axis.text.y = element_text(size=10),
              legend.position = "none", legend.direction = "vertical")
      plot.7h
      
      plot.7i <- datum |>
        filter(NLR < 8) |>
        ggplot(aes(x=sqrt(Breakpoint), y=sqrt(Lower_rate), col=Pop))+
        geom_point( pch=16, size=5)+
        geom_line(stat='smooth', method = "lm",linewidth = 1)+
        geom_ribbon(aes(col = NULL, group = Pop), stat='smooth', method = "lm", se=TRUE, alpha=0.1)+
        scale_color_manual("Treatment:", values=my_pal2)+
        theme(axis.text.x = element_text(size = 11),
              axis.title = element_text(size = 13),
              axis.text.y = element_text(size=10),
              legend.position = "none", legend.direction = "vertical")
      plot.7i
      
    #NLR vs others
      plot.7j <- datum |>
        filter(NLR < 8) |>
        ggplot(aes(x=sqrt(NLR), y=sqrt(RI), col=Pop))+
        geom_point( pch=16, size=5)+
        geom_line(stat='smooth', method = "lm",linewidth = 1)+
        geom_ribbon(aes(col = NULL, group = Pop), stat='smooth', method = "lm", se=TRUE, alpha=0.1)+
        scale_color_manual("Treatment:", values=my_pal2)+
        theme(axis.text.x = element_text(size = 11),
              axis.title = element_text(size = 13),
              axis.text.y = element_text(size=10),
              legend.position = "none", legend.direction = "vertical")
      plot.7j
      
      plot.7k <- datum |>
        filter(NLR < 8) |>
        ggplot(aes(x=sqrt(NLR), y=sqrt(Upper_rate), col=Pop))+
        geom_point( pch=16, size=5)+
        geom_line(stat='smooth', method = "lm",linewidth = 1)+
        geom_ribbon(aes(col = NULL, group = Pop), stat='smooth', method = "lm", se=TRUE, alpha=0.1)+
        scale_color_manual("Treatment:", values=my_pal2)+
        theme(axis.text.x = element_text(size = 11),
              axis.title = element_text(size = 13),
              axis.text.y = element_text(size=10),
              legend.position = "none", legend.direction = "vertical")
      plot.7k
      
      plot.7l <- datum |>
        filter(NLR < 8) |>
        ggplot(aes(x=sqrt(NLR), y=sqrt(Lower_rate), col=Pop))+
        geom_point( pch=16, size=5)+
        geom_line(stat='smooth', method = "lm",linewidth = 1)+
        geom_ribbon(aes(col = NULL, group = Pop), stat='smooth', method = "lm", se=TRUE, alpha=0.1)+
        scale_color_manual("Treatment:", values=my_pal2)+
        theme(axis.text.x = element_text(size = 11),
              axis.title = element_text(size = 13),
              axis.text.y = element_text(size=10),
              legend.position = "bottom", legend.direction = "horizontal")
      plot.7l
      
   #RI vs others
      plot.7m <- datum |>
        filter(NLR < 8) |>
        ggplot(aes(x=sqrt(RI), y=sqrt(Upper_rate), col=Pop))+
        geom_point( pch=16, size=5)+
        geom_line(stat='smooth', method = "lm",linewidth = 1)+
        geom_ribbon(aes(col = NULL, group = Pop), stat='smooth', method = "lm", se=TRUE, alpha=0.1)+
        scale_color_manual("Treatment:", values=my_pal2)+
        theme(axis.text.x = element_text(size = 11),
              axis.title = element_text(size = 13),
              axis.text.y = element_text(size=10),
              legend.position = "none", legend.direction = "vertical")
      plot.7m
      
      plot.7n <- datum |>
        filter(NLR < 8) |>
        ggplot(aes(x=sqrt(RI), y=sqrt(Lower_rate), col=Pop))+
        geom_point( pch=16, size=5)+
        geom_line(stat='smooth', method = "lm",linewidth = 1)+
        geom_ribbon(aes(col = NULL, group = Pop), stat='smooth', method = "lm", se=TRUE, alpha=0.1)+
        scale_color_manual("Treatment:", values=my_pal2)+
        theme(axis.text.x = element_text(size = 11),
              axis.title = element_text(size = 13),
              axis.text.y = element_text(size=10),
              legend.position = "none", legend.direction = "vertical")
      plot.7n
      
      #Upper vs lower
      plot.7o <- datum |>
        filter(NLR < 8) |>
        ggplot(aes(x=sqrt(Upper_rate), y=sqrt(Lower_rate), col=Pop))+
        geom_point( pch=16, size=5)+
        geom_line(stat='smooth', method = "lm",linewidth = 1)+
        geom_ribbon(aes(col = NULL, group = Pop), stat='smooth', method = "lm", se=TRUE, alpha=0.1)+
        scale_color_manual("Treatment:", values=my_pal2)+
        theme(axis.text.x = element_text(size = 11),
              axis.title = element_text(size = 13),
              axis.text.y = element_text(size=10),
              legend.position = "none", legend.direction = "horizontal")
      plot.7o
      
      jpeg(file = "Statistics correlations.jpg", units = "in", width = 14, height = 14, res = 300)
      plot.7 + plot.7b + plot.7c + plot.7d + plot.7e + 
      plot_spacer() + plot.7f + plot.7g + plot.7h + plot.7i +
      plot_spacer() + plot_spacer() + plot.7j + plot.7k + plot.7l +
      plot_spacer() + plot_spacer() + plot_spacer() + plot.7m + plot.7n +
      plot_spacer() + plot_spacer() + plot_spacer() + plot_spacer() + plot.7o + plot_layout(ncol = 5, nrow = 5, byrow=FALSE) 
      dev.off()
  